/*
������ "������������"
���� dsheet.cpp
  ����������
    ���������� ������ DSheetPic
  �������
    20.07.97 ������
*/

#include "PasObjIterator.h"

DSheetPic::DSheetPic( DOwnerPic *own ) :
  DGraphTopPic( own ),
  picture( 30, 30, true ),
  comp( 10, 10, true ),
  nets( 30, 30, true ),
  areas( 5, 5, true ) {
    }

DSheetPic::DSheetPic( CPChar nm, CPChar param ) :
  DGraphTopPic( nm, param ),
  picture( 30, 30, true ),
  comp( 10, 10, true ),
  nets( 30, 30, true ),
  areas( 5, 5, true ) {
    }

DSheetPic::~DSheetPic() { }

void
DSheetPic::Write( DStream &os ) {
  DGraphTopPic::Write( os );
  picture.Write( os );
  comp.Write( os );
  nets.Write( os );
  areas.Write( os );
  os.Write( &info, sizeof(DSheetInfo) );
  }

void
DSheetPic::Read( DStream &is ) {
  DGraphTopPic::Read( is );
  picture.Read( is, this );
  comp.Read( is, this );
  nets.Read( is, this );
  areas.Read( is, this );
  if( is.GetVersion() == 10 ) {
    GetParam().Read( is );
    }
  is.Read( &info, sizeof(DSheetInfo) );
  }

PDBasePic
DSheetPic::Copy() {
  DSheetPic *sheet = new DSheetPic( GetName(), GetParamString() );
  if( sheet ) {
    picture.CopyTo( sheet );
    comp.CopyTo( sheet );
    nets.CopyTo( sheet );
    }
  else throw CadError("DSheetPic::Copy");
  return 0;
  }

bool
DSheetPic::ForEach( DBaseIterator<DBasePic> &iterator ) {
  return ForEachMember( picture, iterator ) &&
         ForEachMember( comp, iterator ) &&
         ForEachMember( nets, iterator ) &&
         ForEachMember( areas, iterator );
  }

/*
class NetIterator {
    DBaseIterator<DGraphObjectPic> &iterator;
  public:
    NetIterator( DBaseIterator<DGraphObjectPic> &iter ) : iterator(iter) {}

    bool operator () ( DSheetNetPic *net ) {
      return net->ForEachGraph( iterator );
      }
  };

bool
DSheetPic::ForEachWire( DBaseIterator<DGraphObjectPic> &iterator ) {
  NetIterator netIterator(iterator);
  return ForEachMember( nets, netIterator );
  }

bool
DSheetPic::ForEachGraph( DBaseIterator<DGraphObjectPic> &iterator ) {
  return ForEachMember( picture, iterator ) &&
         ForEachMember( comp, iterator ) &&
         ForEachWire( iterator ) && //nets
         ForEachMember( areas, iterator );
  }
  */
class GetAreaNumIterator {
    DPoint     point;
    DPlatePic *plate;
  public:
    GetAreaNumIterator( DPoint p ) : point(p), plate(0) {}

    bool operator () ( DAreaPic *area ) {
      if( area->IsPointInside( point ) ) plate = area->GetPlate();
      return !plate;
      }

    DPlatePic *GetPlate() { return plate; }
  };

DPlatePic*
DSheetPic::GetPlate( DPoint point ) {
  DProjectPic *prj = GetProject();
  if( !prj ) throw CadError("DSheetPic::GetPlate: ��� �������");
  DPlatePic *plate = dynamic_cast<DPlatePic*>( prj->FindObject("�����������") );
  if( !plate ) {
    //����� ��� �� ����������
    prj->Insert( new DPlatePic( "�����������", "" ) );
    plate = dynamic_cast<DPlatePic*>( prj->FindObject("�����������") );
    if( !plate ) throw CadError("DSheetPic::GetPlate: ������ �������� �����");
    }
  GetAreaNumIterator areaIterator( point );
  if( ForEachMember( areas, areaIterator ) ) return plate;
  return areaIterator.GetPlate();
  }

int
DSheetPic::GetPlateIndex( DPoint point ) {
  return GetPlate(point)->GetIndex();
  }


void
DSheetPic::Insert( PDBasePic pic ) {
  if( !pic ) throw( CadError("DSheetPic::Insert:��� �������") );
  switch( pic->GetType() ) {
    case dptLinePic :
    case dptRegionPic :
    case dptRectPic :
    case dptFillRectPic :
    case dptCirclePic :
    case dptArcPic :
    case dptTextPic :
    case dptNetListPic :
      picture.Add( dynamic_cast<DGraphObjectPic*>(pic) );
      break;
    case dptAreaPic :
      areas.Add( dynamic_cast<DAreaPic*>(pic) );
      break;
    case dptSheetNetPic :
      nets.Add( dynamic_cast<DSheetNetPic*>(pic) );
      break;
    case dptSymImpPic :
      comp.Add( dynamic_cast<DSymImpPic*>(pic) );
      break;
    default : throw( CadError("DSheetPic::Insert:�� ��� ���") );
    }
  //��� ������, ������� �������
  DOwnerPic::Insert( pic );
  }

void
DSheetPic::Remove( PDBasePic pic ) {
  if( !pic ) throw( CadError("DSheetPic::Remove") );
  //���������� �������� �������� ������ �� ��������
  if( picture.Remove( dynamic_cast<DGraphObjectPic*>(pic) ) ||
      areas.Remove( dynamic_cast<DAreaPic*>(pic) ) ||
      nets.Remove( dynamic_cast<DSheetNetPic*>(pic) ) ||
      comp.Remove( dynamic_cast<DSymImpPic*>(pic) ) )
    DOwnerPic::Remove( pic );
  }

class GetNetIterator {
    CPChar        name;
    DSheetNetPic *net;
  public:
    GetNetIterator( CPChar nm ) : name(nm), net(0) {}

    bool operator () ( DSheetNetPic *sour ) {
      if( (*sour) == name ) net = sour;
      return !net;
      }
    DSheetNetPic* GetNet() { return net; }
  };

DSheetNetPic*
DSheetPic::GetNet( CPChar sour ) {
  GetNetIterator iterator( sour );
  ForEachMember( nets, iterator );
  return iterator.GetNet();
  }

DSheetNetPic*
DSheetPic::CreateNet( CPChar sour ) {
  //��������� ������������� ���� � ����� ������
  DSheetNetPic *net = GetNet( sour );
  if( !net ) {
    //���� � ����� ������ ���, �������
    net = new DSheetNetPic( sour );
    //�������� � ����� ������
    Insert( net );
    }
  return net;
  }

class GetNetFromPointIterator : public DownIterator {
    DPoint  point;
    DName  &name;
  public:
    GetNetFromPointIterator( DPoint p, DName &n ) : point(p), name(n) {}

    bool operation( DBasePic *base ) {
      DWiringPic *wire = dynamic_cast<DWiringPic*>(base);
      if( wire ) return !wire->GetNetOnPoint( point, name );
      return true;
      }
  };

bool
DSheetPic::GetNetFromPoint( DPoint p, DName &name ) {
  return !ForEach( GetNetFromPointIterator( p, name ) );
  }

void
DSheetPic::NetWirePlace( DPoint a, DPoint b, CPChar name ) {
  for( int i = 0; i < comp.GetNumber(); ++i ) comp[i]->NetWirePlace( a, b, name );
  }

void
DSheetPic::NetWireDelete( DPoint a, DPoint b, CPChar name ) {
  for( int i = 0; i < comp.GetNumber(); ++i ) comp[i]->NetWireDelete( a, b, name );
  }

void
DSheetPic::AccumLinked( DPoint a, DPoint b, DSelectorPic &selector ) {
  for( int i = 0; i < comp.GetNumber(); ++i ) comp[i]->AccumLinked( a, b, selector );
  }





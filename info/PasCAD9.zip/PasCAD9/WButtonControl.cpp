/*
������ "Windows"
���� WButtonControl.cpp
  ����������
    ���������� WButtonControl
  �������
    10.01.2001 ������
*/

#include "WinPasCAD.h"

void
WButtonControl::SetButtons( int *buttons, int count, NDialog *owner ) {
  int x = 0;
  for( int i = 0; i < count; ++i ) {
    NToolButton *button = new NToolButton;
    button->state     = 0;
    button->style     = (i == 0 ? NToolButton::slGroup : 0) | NToolButton::slSwitch | NToolButton::slMarker;
    button->leftTop.x = x;
    button->leftTop.y = 0;
    button->cmdRelease =
    button->cmdPress  = buttons[i];
    button->pCommand  = 0;
    button->bitMap.LoadBitmap( buttons[i] );
    x += NToolButton::width;
    AddButton( button, false );
    }
  RecalcSize();
  dialog = owner;
  }

bool
WButtonControl::GetPressed( int index ) {
  if( index >= 0 && index < buttonTable.GetNumber() ) return (buttonTable[index]->state & NToolButton::stPressed);
  return false;
  }

void
WButtonControl::SetPressed( int index, bool state ) {
  if( index >= 0 && index < buttonTable.GetNumber() )
    if( state ) buttonTable[index]->state |= NToolButton::stPressed;
    else buttonTable[index]->state &= ~NToolButton::stPressed;
  InvalidateRect( 0 );
  }
/*
void
WButtonControl::ReleaseAll() {
  FOR_EACH( buttonTable )
    buttonTable[i]->state &= ~NToolButton::stPressed;
  InvalidateRect( 0 );
  }
*/

bool
WButtonControl::WmLButtonDown( WPARAM wParam, LPARAM lParam ) {
  NToolButtonWindow::WmLButtonDown( wParam, lParam );
  if( dialog ) dialog->WmNotifyCode( 0, WM_VSCROLL, 0 );
  return true;
  }


/*
������ "������� �� PasCAD � P-CAD"
���� ConvertIO.cpp
����������
  ���������� �������-������ ������
�������
  17.05.02 ������ �� ������ exppcad ��� V7
*/
#include "exppcad/PcadEXPH.h"

CPChar
  spaceChar = " ",
  eolnChar  = "\n",
  szClose   = "}\n";

void DUserOperator::puts( LPCSTR str ) { os << str; }

void DUserOperator::putsw( LPCSTR str ) { os << str << spaceChar; }

void DUserOperator::putsn( LPCSTR str ) { os << str << eolnChar; }

void DUserOperator::puti( int i ) { os << i; }

void DUserOperator::putis( int i ) { os << i / 25; }

void DUserOperator::putiw( int i ) { os << i << spaceChar; }

void DUserOperator::putiws( int i ) { os << i / 25 << spaceChar; }

void DUserOperator::putin( int i ) { os << i << eolnChar; }

void DUserOperator::putins( int i ) { os << i / 25 << eolnChar; }

void DUserOperator::putPoint( DPoint p ) { os << p.x / 25 << spaceChar << p.y / 25; }

void DUserOperator::putPointw( DPoint p ) { os << p.x / 25 << spaceChar << p.y / 25 <<spaceChar; }

void DUserOperator::closeSection() { os << szClose << eolnChar; }

void DUserOperator::eoln() { os << eolnChar; }


//========================== �������� ��������� ��������� ======================
void
DUserOperator::setLayer( int layer ) {
  puts( "[Ly \"" );
  if( layer >= 0 && layer < table.GetNumber() ) puts( table[layer].pcad );
  else puts( "CMP" );
  putsn( "\"]" );
  activeLayer = layer;
  }

void
DUserOperator::checkLayer( int layer ) {
  if( layer != activeLayer ) setLayer( layer );
  }

void
DUserOperator::checkLine( int width, int type ) {
  CPChar str = 0;
  if( type != lineType ) {
    puts( "[Ls " );
    switch( lineType = type ) {
      case dltSolid : str = "\"SOLID\"]"; break;
      case dltDotted : str = "\"DOTTED\"]"; break;
      case dltDashed : str = "\"DASHED\"]"; break;
      }
    putsn( str );
    }
  if( width != lineWidth ) {
    puts( "[Wd " );
    putis( lineWidth = width );
    putsn( "]" );
    }
  else eoln();
  }

void
DUserOperator::checkText( int size, int dir, int hjust, int vjust, int mirror ) {
  int flag = 0;
  if( size != textSize ) {
    textSize = size;
    puts( "[Ts " );
    putis( textSize > 25 ? textSize : 6 * 25 );
    puts( "]" );
    flag = 1;
    }
  if( hjust != textHJust || vjust != textVJust ) {
    char str[3];
    puts( "[Tj \"" );
    switch( textHJust = hjust ) {
      case dhjLeft : str[0] = 'L'; break;
      case dhjCenter : str[0] = 'C'; break;
      case dhjRight : str[0] = 'R'; break;
      }
    switch( textVJust = vjust ) {
      case dvjTop : str[1] = 'T'; break;
      case dvjCenter : str[1] = 'C'; break;
      case dvjBottom : str[1] = 'B'; break;
      }
    str[2] = 0;
    puts( str );
    puts( "\"]" );
    flag = 1;
    }
  if( dir != textDir ) {
    puts( "[Tr " );
    puti( (textDir = dir) / 90000 );
    puts( "]" );
    flag = 1;
    }
  if( mirror != textMirror ) {
    char str[2];
    switch( textMirror = mirror ) {
      case dmMirror : str[0] = 'Y'; break;
      default :
      case dmNoMirror : str[0] = 'N'; break;
      }
    str[1] = 0;
    puts( "[Tm \"" );
    puts( str );
    puts( "\"]" );
    flag = 1;
    }
  if( flag ) eoln();
  }
  

/*
������ "������� �� PasCAD � P-CAD"
���� PcadEXPH.h
����������
  ������� ������������ ����
�������
  17.05.02 ������ �� ������ exppcad ��� V7
*/
#include "ExpPasCAD.h"
#include "exppcad/ExpPcad.rh"
#include <fstream.h>

#define EXP_VERSION 2

//������������ ��������
struct Config {
  NPath             pcadImp;   //���� � pdifin.exe
  NPath             directory; //������� ����������
  NPath             layerFile; //���� ������������ ���� �����
  };

extern Config config;

extern bool bKompas; //��������� ������ ������������� � ������

typedef NConstString<16> PcadName;

struct CompEqual {
  DWName symName;
  DWName prtName;

  CompEqual() : symName(), prtName() {}

  CompEqual( LPCSTR sym, LPCSTR prt ) :
    symName(sym),
    prtName(prt)
    { }
  bool Match( CompEqual &cmp ) { return symName == cmp.symName && prtName == cmp.prtName; }
  };

struct PLayer {
  DWName   pascad;
  PcadName pcad;
  };


class DUserOperator : public DBaseUserOperator {
    NVector<PLayer>    table;      //������� �����
    NVector<CompEqual> compTable;  //������� �����������
    int      activeLayer;
    int      pathLayer;
    int      pathWidth;
    int      lineType;
    int      lineWidth;
    int      textSize;
    int      textHJust;
    int      textVJust;
    int      textDir;
    int      textMirror;
    bool     pathFlag;
    DPoint   globalOrigin;
    DPoint   startPathPoint;
    NPath    file;
    ofstream os;
    NWindow *own;
  protected:
    void puts( LPCSTR str );
    void putsw( LPCSTR str );
    void putsn( LPCSTR str );
    void puti( int i );
    void putis( int i );  //����� ������ � ����������������
    void putiw( int i );
    void putiws( int i ); //����� ������ � ����������������
    void putin( int i );
    void putins( int i ); //����� ������ � ����������������
    void putPoint( DPoint p );
    void putPointw( DPoint p );
    void closeSection();
    void eoln();
    void setLayer( int layer );
    void checkLayer( int layer );
    void checkLine( int width, int type );
    void checkText( int size, int dir, int hjust, int vjust, int mirror );
    void Display();                            //������ "DISPLAY"
    void User( LPCSTR mode, LPCSTR gridStep ); //������ "USER"
    void Environment( LPCSTR dbType );         //������ "ENVIRONMENT"
    bool PrepareFile( CPChar szExt, CPChar defExt );
    int  CompLook( LPCSTR sym, LPCSTR prt );
    LPCSTR ReplaceName( LPCSTR sym, LPCSTR prt, BOOL isSym = FALSE );
  public:
    DUserOperator( NWindow *win );
    ~DUserOperator();

    virtual bool FBasePic( DBasePic* ) { return true; }
    virtual bool FOwnerPic( DOwnerPic *pic ) { return FBasePic( pic ); }
    virtual bool FSheetNetPic( DSheetNetPic *pic );
    virtual bool FPlateNetPic( DPlateNetPic *pic );
    virtual bool FProjectPic( DProjectPic *pic ) { return FOwnerPic( pic ); }
    virtual bool FContainerPic( DContainerPic *pic ) { return FOwnerPic( pic ); }
    virtual bool FAliasPic( DAliasPic *pic ) { return FContainerPic( pic ); }
    virtual bool FTextDocPic( DTextDocPic *pic ) { return FContainerPic( pic ); }
    virtual bool FGraphTopPic( DGraphTopPic *pic ) { return FContainerPic( pic ); }
    virtual bool FSymbolPic( DSymbolPic *pic );
    virtual bool FSheetPic( DSheetPic *pic ) { return FGraphTopPic( pic ); }
    virtual bool FPrtPic( DPrtPic *pic );
    virtual bool FPlatePic( DPlatePic *pic ) { return FGraphTopPic( pic ); }
    virtual bool FSelectorPic( DSelectorPic *pic ) { return FBasePic( pic ); }
    virtual bool FGraphObjectPic( DGraphObjectPic *pic ) { return FBasePic( pic ); }
    virtual bool FLinearPic( DLinearPic *pic );
    virtual bool FLinePic( DLinePic *pic );
    virtual bool FRectPic( DRectPic *pic );
    virtual bool FFillRectPic( DFillRectPic *pic );
    virtual bool FCirclePic( DCirclePic *pic );
    virtual bool FArcPic( DArcPic *pic );
    virtual bool FLineSizePic( DLineSizePic *pic ) { return FLinearPic( pic ); }
    virtual bool FCircleSizePic( DCircleSizePic *pic ) { return FLinearPic( pic ); }
    virtual bool FTextPic( DTextPic *pic );
    virtual bool FIdentPic( DIdentPic *pic );
    virtual bool FSymPinPic( DSymPinPic *pic );
            bool FSymPinDef( DSymPinPic *pic );
            bool FSymPinPkg( DSymPinPic *pic );
            bool FSymPinPak( DSymPinPic *pic, int section );
            bool FSymPinNum( DSymPinPic *pic, int section );
    virtual bool FPrtPinPic( DPrtPinPic *pic );
    virtual bool FWiringPic( DWiringPic *pic ) { return FGraphObjectPic( pic ); }
    virtual bool FWirePic( DWirePic *pic );
    virtual bool FSymImpPic( DSymImpPic *pic );
    virtual bool FWireNamePic( DWireNamePic *pic );
    virtual bool FRoadPic( DRoadPic *pic ) { return FGraphObjectPic( pic ); }
    virtual bool FTrasePic( DTrasePic *pic );
    virtual bool FPolygonPic( DPolygonPic *pic );
    virtual bool FViaPic( DViaPic *pic );
    virtual bool FPrtImpPic( DPrtImpPic *pic );
    virtual bool FAreaPic( DAreaPic *pic ) { return FGraphObjectPic( pic ); }
    virtual bool FNetListPic( DNetListPic *pic ) { return FGraphObjectPic( pic ); }
    virtual bool FRegionPic( DRegionPic *pic ) { return FGraphObjectPic( pic ); }
            bool FTopPrtPic( DPrtPic *prt );
            bool FTopPlatePic( DPlatePic *plate );
            bool FTopSheetPic( DSheetPic *sheet );
            bool FTopSymbolPic( DSymbolPic *symbol );
            bool CreatePrtCompDef( DPrtImpPic *comp );
            bool FWirePicDot( DWirePic *wire );
            bool FSymCompDef( DSymImpPic *sym );
            CPChar GetFile() const { return file; }
  };

class DIExport : public DBaseIterator<DBasePic> {
    DUserOperator *op;
  public:
    DIExport( DUserOperator *o ) : op(o) {}

    bool operator () ( DBasePic *pic ) { return op->Operation( pic ); }
  };

#define DIPExport( Class, Base, Operation ) \
  class Class : public DBaseIterator<Base> { \
    DUserOperator *op;                           \
  public:                                        \
    Class( DUserOperator *o ) : op(o) {}         \
                                                 \
    bool operator () ( Base *pic ) { return op->Operation( pic ); } \
  }

class DIExportPrtPin : public DBaseIterator<DPrtPinPic> {
    DUserOperator *op;
  public:
    DIExportPrtPin( DUserOperator *o ) : op(o) {}

    bool operator () ( DPrtPinPic *pic ) { return op->FPrtPinPic( pic ); }
  };

class DIExportGraph : public DBaseIterator<DGraphObjectPic> {
    DUserOperator *op;
  public:
    DIExportGraph( DUserOperator *o ) : op(o) {}

    bool operator () ( DGraphObjectPic *pic ) { return op->Operation( pic ); }
  };

class DPCADExport : public DBMaster {
  protected:
    void AutoCreate( CPChar fileName, CPChar szFile, NWindow *own, bool bPlate = false );
  public:
    DPCADExport();

    virtual int  ShortEnter( NWindow *parent, CPChar path, DSelectResultEx *res );
    virtual void WriteConfig( NFile &os );
    virtual void ReadConfig( NFile &is, int version );
    virtual void InitConfig();

            void SymExport( NWindow *parent, DSelectResultEx *result );
            void PrtExport( NWindow *parent, DSelectResultEx *result );
            void SheetExport( NWindow *parent, DSelectResultEx *result );
            void PlateExport( NWindow *parent, DSelectResultEx *result );
            void TestPDifIn();
  };

class WDEditLayers : public NDialog {
    NVector<PLayer> &table;
    NStaticControl   state;
    //NCheckControl    kompas;
  public:
    WDEditLayers( NVector<PLayer> &t );

    virtual void WmInit();
    virtual bool WmCommand( WPARAM wParam, LPARAM lParam );
  protected:
    void CmLoad();
    void CmSave();
    void CmSaveAs();
    void LoadLayers();
  };


/*
������ "������������"
���� DScaner.cpp
����������
�������
  03.08.2002 ������
*/
#include "WinPasCAD.h"

//==============================================================================
//---------------------- DSFloat -----------------------------------------------
DSFloat::DSFloat( void *item, int offset, DScaner *n ) :
  DScaner( n ) {
    dest = (double*)( ((CPChar)(item)) + offset );
    }

bool
DSFloat::Scan( NTextParser &parser ) {
  //��������� ����� � ��������� ������
  parser.Blank();
  bool res = parser.ScanFloat( *dest );
  parser.Blank();
  return res && parser.GetChar() == ';';
  }

void
DSFloat::GenerInit() { }

//==============================================================================
//---------------------- DSPhis ------------------------------------------------
DSPhis::DSPhis( void *item, int offset, CPChar nm, DScaner *n ) :
  DScaner( n ),
  name( nm ) {
    dest = (double*)( ((CPChar)(item)) + offset );
    }

bool
DSPhis::Scan( NTextParser &parser ) {
  //��������� ����� � ��������� ������
  parser.Blank();
  bool res = parser.ScanPhis( *dest, name, 0 );
  parser.Blank();
  return res && parser.GetChar() == ';';
  }

void
DSPhis::GenerInit() {}

//==============================================================================
//---------------------- DSPhisInterval ----------------------------------------
double ve6[] = { 1.0, 1.5, 2.2, 3.3, 4.7, 6.8 },
       ve12[] = { 1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.1 },
       ve24[] = { 1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1},
       ve48[] = { 1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1},
       ve96[] = { 1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1},
       ve192[]= { 1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
                  1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
                  3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1};

DSPhisInterval::DSPhisInterval( void *item, int offset, CPChar nm, DScaner *n ) :
  DScaner( n ),
  name( nm ),
  count(0),
  ptr(0),
  type(0) {
    dest = (double*)( ((CPChar)(item)) + offset );
    }

bool
DSPhisInterval::Scan( NTextParser &parser ) {
  //��������� ������ ����: 2.2 �� : 820 �� ! �24
  //���                    2.2 �� : 820 �� ! 23 ��
  parser.Blank();
  if( !parser.ScanPhis( begin, name, 0 ) ) return false;
  parser.Blank();
  if( parser.GetChar() != ':' ) return false;
  parser.Blank();
  if( !parser.ScanPhis( end, name, 0 ) ) return false;
  parser.Blank();
  if( parser.GetChar() != '!' ) return false;
  parser.Blank();
  if( parser.PeekChar() == 'e' || //����������� �
      parser.PeekChar() == 'E' ||
      parser.PeekChar() == '�' || //������� ������
      parser.PeekChar() == '�' ) {
        //��� ������ ����� ���
        parser.GetChar(); //���������� �
        parser.ScanInt( type );
        step = 1.0;
        }
  else {
    //��� ���������� � ������ ����
    if( !parser.ScanPhis( step, name, 0 ) ) return false;
    if( step == 0 ) step = 1.0;
    type = 0;
    }
  parser.Blank();

  return parser.GetChar() == ';';
  }

void
DSPhisInterval::GenerInit() {
  switch( type ) {
    case 0   : count = (end - begin) / step; *dest = begin; break;
    case 6   : ptr = ve6;   count = 6;   break;
    case 12  : ptr = ve12;  count = 12;  break;
    case 24  : ptr = ve24;  count = 24;  break;
    case 48  : ptr = ve48;  count = 48;  break;
    case 96  : ptr = ve96;  count = 96;  break;
    case 192 : ptr = ve192; count = 192; break;
    default : throw CadError( "DSPhisInterval::GenerInit: ����������� ���" );
    }
  //�������� ������ ���������� ��������
  multer = 100000000.0;
  while( multer >= begin ) multer /= 10.0;
  *dest = multer;
  while( *dest < begin ) Gener();
  }

bool
DSPhisInterval::Gener() {
  if( *dest < end ) {
    if( type ) {
      //������� ��������� �������� �� ����
      if( count ) *dest = *ptr++ * multer;
      else {
        multer *= 10;
        switch( type ) {
          case 6   : ptr = ve6;   count = 6;   break;
          case 12  : ptr = ve12;  count = 12;  break;
          case 24  : ptr = ve24;  count = 24;  break;
          case 48  : ptr = ve48;  count = 48;  break;
          case 96  : ptr = ve96;  count = 96;  break;
          case 192 : ptr = ve192; count = 192; break;
          }
        }
      count--;
      }
    else {
      //��������� ��������� ��������
      *dest += step;
      }
    return *dest < end;
    }
  return false;
  }

//==============================================================================
//---------------------- DSPhis ------------------------------------------------
DSStrList::DSStrList( void *item, int offset, int len, DScaner *n ) :
  DScaner( n ),
  mmax(len),
  list( 5, 5 ) {
    dest = ((PChar)(item)) + offset;
    }

bool
DSStrList::Scan( NTextParser &parser ) {
  //��������� ����� ��������
  NPath tmp;
  while( !parser.Eof() && parser.PeekChar() != ';' ) {
    parser.Blank();
    int i;
    for( i = 0; i < tmp.GetSize() - 1 && parser.PeekChar() != '|' && parser.PeekChar() != ';'; ++i )
      tmp[i] = parser.GetChar();
    tmp[i] = 0;
    list.Add( tmp );
    if( parser.PeekChar() == '|' ) parser.GetChar();
    }
  return true;
  }

void
DSStrList::GenerInit() {
  count = 0;
  strncpy( dest, list[count++], mmax );
  }

bool
DSStrList::Gener() {
  if( count < list.GetNumber() ) {
    strncpy( dest, list[count++], mmax );
    return true;
    }
  return false;
  }



/*
������ "������������"
���� WPlateWindow.cpp
����������
  ���������� WPlateWindow
�������
  30.10.2001 ������
*/

#include "WinModes.h"

const int
  cntPlatePanel   = 14,
  cmdFlag         = NToolButton::slCmdRelease | NToolButton::slMarker;

NToolButtonDef
  ntbdPlatePanel[cntPlatePanel] = {
    {0, NToolButton::slSeparator },
    {IDM_OBJ_RATNET, NToolButton::slCmdPress | NToolButton::slCmdRelease | NToolButton::slMarker |NToolButton::slSwitch },
    {0, NToolButton::slSeparator },
    {IDM_OBJ_LINESIZE, cmdFlag},
    {IDM_OBJ_CIRCLESIZE, cmdFlag},
    {0, NToolButton::slSeparator },
    {IDM_OBJ_PRT, cmdFlag},
    {IDM_OBJ_PRTPLACE, cmdFlag },
    {0, NToolButton::slSeparator },
    {IDM_WIRE_SELECT, cmdFlag},
    {IDM_OBJ_PWIRE, cmdFlag},
    {IDM_OBJ_PWIREDEL, cmdFlag},
    {IDM_OBJ_POLYGON, cmdFlag},
    {IDM_OBJ_VIA, cmdFlag} };

NControlBar *WPlateWindow::bar;

DBHistory WPlateWindow::exportNavigator( 5, FLD_EXPORT_ROOT SUBFLD_PLATE );
DBHistory WPlateWindow::importNavigator( 5, FLD_IMPORT_ROOT SUBFLD_PLATE );

WPlateWindow::WPlateWindow( HWND hWnd ) :
  WGraphWindow( hWnd ) {
    ppm = 1000.0;
    grid.x = 2500;
    grid.y = 2500;
    //������� � ���������� ������ ������������ ��� �������
    if( !bar ) {
      bar = WFrame::pFrame->CreateControlBar();
      if( bar ) {
        //��������� ������ �������������
        AssignGraphBar( bar );

        //������ �������� �������
        NXButtonControlWindow *buttons = WFrame::pFrame->CreateXToolButtons( bar );
        buttons->SetButtons( ntbdPlatePanel, cntPlatePanel );
        bar->AddBarItem( 0, buttons );
        AddNewLineBar( bar );
        }
      }
    }

NMenu*
WPlateWindow::GetObjMenu() {
  //������� ����
  static NLoadedMenu menu( PLATE_MENU );
  static bool bAuto = true;
  //��� ������ ������ �������� ������ ���� "�������������"
  if( bAuto ) {
    AddToolMenu( &menu, FLD_TOOLS_ROOT SUBFLD_PLATE, 8, this );
    bAuto = false;
    }
  return &menu;
  }

NMenu*
WPlateWindow::GetSelectMenu() {
  static NLoadedMenu selectMenu( PLATE_POPMENU );
  return &selectMenu;
  }

bool
WPlateWindow::WmCommand( WPARAM wParam, LPARAM lParam ) {
  switch( LOWORD(wParam) ) {
    case IDM_OBJ_RATNET     : CmRatNet(); break;
    case IDM_PADSTACK       : CmPads(); break;
    case IDM_OBJ_LINESIZE   : SetMode( new DLineSizeMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    case IDM_OBJ_CIRCLESIZE : SetMode( new DCircleSizeMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    case IDM_OBJ_PRT        : SetMode( new WinPrtImpMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    case IDM_OBJ_PRTPLACE   : SetMode( new WinPlaceMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    case IDM_OBJ_PWIRE      : SetMode( new WinTraseMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    case IDM_MOVE_IDENT     : SetMode( new DMoveIdentMode( this, DPointer( DGraphTopPic, GetObject()) ) ); break;
    case IDM_EDIT_MASK      : CmMask(); break;
    case IDM_OBJ_VIA        : SetMode( new DViaMode( this, DPointer( DGraphTopPic, GetObject()) ) ); break;
    case IDM_OBJ_POLYGON    : SetMode( new WinPolygonMode( this, DPointer( DGraphTopPic, GetObject()) ) ); break;
    case IDM_OBJ_PWIREDEL   : SetMode( new DRoadDeleteMode( this, DPointer( DPlatePic, GetObject()) ) ); break;
    //case IDM_WIRE_SELECT    : Trasser(); break;
    default : return WGraphWindow::WmCommand( wParam, lParam );
    }
  return true;
  }

int
WPlateWindow::GetCommandState( int cmd ) {
  switch( cmd ) {
    case IDM_OBJ_RATNET     : return GetEnvir().showRatNet ? cmdChecked|cmdEnabled : cmdEnabled;
    case IDM_PADSTACK       :
    case IDM_OBJ_LINESIZE   :
    case IDM_OBJ_CIRCLESIZE :
    case IDM_OBJ_PRT        :
    case IDM_OBJ_PRTPLACE   :
    case IDM_EDIT_MASK      :
    case IDM_MOVE_IDENT     :
    case IDM_OBJ_VIA        :
    case IDM_OBJ_POLYGON    :
    case IDM_OBJ_PWIREDEL   :
    //case IDM_WIRE_SELECT    :
    case IDM_OBJ_PWIRE      : break;
    default : return WGraphWindow::GetCommandState( cmd );
    }
  if( GetMode() && GetMode()->GetIndex() == cmd ) return cmdChecked|cmdEnabled;
  return cmdEnabled;
  }

void
WPlateWindow::CmRatNet() {
  GetEnvir().showRatNet = !GetEnvir().showRatNet;
  if( GetBaseObject() && GetBaseObject()->GetProject() )
    GetBaseObject()->GetProject()->SetDirty();
  Update();
  }

void
WPlateWindow::CmPads() {
  WDPadStack( DPointer( DPlatePic, GetObject())  ).Execute( this );
  Update();
  }

void
WPlateWindow::CmMask() {
  WDMask().Execute( this );
  }




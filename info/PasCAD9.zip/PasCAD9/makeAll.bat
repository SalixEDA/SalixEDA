rem library building
call mklib.bat

rem Part Master building
cd PartMaster
make
cd ..

rem P-CAD Export building
cd ExpPCAD
make
cd ..

rem Gerber Export building
cd Gerber
make
cd ..

rem Pads Master building
cd Pads
make
cd ..

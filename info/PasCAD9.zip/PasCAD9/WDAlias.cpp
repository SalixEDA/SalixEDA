/*
������ "������������"
���� WDAlias.cpp
����������
  ���������� WDAlias
�������
  30.10.2001 ������
*/

#include "WinPasCAD.h"

DBHistory WDAlias::exportNavigator( 5, FLD_EXPORT_ROOT SUBFLD_ALIAS );
DBHistory WDAlias::importNavigator( 5, FLD_IMPORT_ROOT SUBFLD_ALIAS );

WDAlias::WDAlias() :
  NDialog( ALIAS_DLG ),
  WObjectView(),
  symbol( IDC_SYMBOL, this, 0, 0, 0 ),
  part( IDC_PRT, this, 0, 0, 0 ),
  param( IDC_PARAM, this, 0, 0, 0 ),
  symbolSelect( IDC_SYM_LIST, this ),
  partSelect( IDC_PRT_LIST, this ),
  apply( IDOK, this ),
  help( IDHELP, this ),
  alias(0) {}

bool
WDAlias::WmCommand( WPARAM wParam, LPARAM lParam ) {
  switch( LOWORD(wParam) ) {
    //��������� �������
    case IDM_SETOBJECT   : CmSetObject( lParam ); break;
    case IDM_TSTOBJECT   : CmTestObject( lParam ); break;
    case IDM_TSTPROJECT  : CmTestProject( lParam ); break;
    case IDM_GETTIME     : CmGetTime( lParam ); break;
    case IDM_ACTIVE      : CmActivate( this ); break;
    case IDM_DEACTIVE    : CmDeactivate(); break;
    case CM_PREPARE_SAVE :
      if( alias && ((DProjectPic*)lParam) == alias->GetProject() ) CmApply(); break;

    case IDC_SYM_LIST    : CmSelectSymbol(); break;
    case IDC_PRT_LIST    : CmSelectPart(); break;
    case IDOK            : CmApply(); break;
    case IDCANCEL        : break;
    default : return NDialog::WmCommand( wParam, lParam );
    }
  return true;
  }

void
WDAlias::CmSetObject( LPARAM lParam ) {
  alias = (DAliasPic*)lParam;
  symbol.SetText( alias && alias->GetSymbol() ? alias->GetSymbol()->GetName() : "" );
  part.SetText( alias && alias->GetPrt() ? alias->GetPrt()->GetName() : "" );
  param.SetText( alias ? alias->GetParamString() : "" );
  }

void
WDAlias::CmTestObject( LPARAM lParam ) {
  SetWindowLong( DWL_MSGRESULT, ((DContainerPic*)lParam) == alias );
  }

void
WDAlias::CmTestProject( LPARAM lParam ) {
  SetWindowLong( DWL_MSGRESULT, alias && alias->GetProject() == ((DProjectPic*)lParam) );
  }

void
WDAlias::CmGetTime( LPARAM lParam ) {
  *((DWORD*)lParam) = active ? GetTickCount() : time;
  }

void
WDAlias::CmActivate( NWindow* ) {
  WObjectView::CmActivate( this );
  InvalidateControl();
  }

void
WDAlias::CmDeactivate() {
  active = false;
  time = GetTickCount();
  }

void
WDAlias::CmApply() {
  //���������� ��������� � ����������
  if( alias ) {
    DString tmp;
    symbol.GetText( tmp );
    alias->SetSymbol( dynamic_cast<DSymbolPic*>( WFrame::pFrame->GetProjectList()->FindObject( tmp ) ) );
    part.GetText( tmp );
    alias->SetPrt( dynamic_cast<DPrtPic*>( WFrame::pFrame->GetProjectList()->FindObject( tmp ) ) );
    //���������� ���������
    param.GetText( tmp );
    alias->GetParam() = tmp;

    symbol.SetText( alias->GetSymbol() ? alias->GetSymbol()->GetName() : "" );
    part.SetText( alias->GetPrt() ? alias->GetPrt()->GetName() : "" );
    param.SetText( alias->GetParamString() );
    alias->GetProject()->SetDirty();
    InvalidateControl();
    }
  }

void
WDAlias::CmSelectSymbol() {
  DSelectResultEx res;
  res.id1 = dptSymbolPic;
  if( WDBrowser( &res, &rootHistory ).Execute( this ) && res.object ) {
    alias->SetSymbol( dynamic_cast<DSymbolPic*>( res.object ) );
    symbol.SetText( alias->GetSymbol() ? alias->GetSymbol()->GetName() : "" );
    }

  //symbol.Exit();
  //SelectDialog select( &WinProgram::winProgram->GetMainWindow()->GetProjectManager(), dptSymbolPic, symbolName, "������" );
  //if( select.Execute( this ) ) symbol.Init();
  }

void
WDAlias::CmSelectPart() {
  DSelectResultEx res;
  res.id1 = dptPrtPic;
  if( WDBrowser( &res, &rootHistory ).Execute( this ) && res.object ) {
    alias->SetPrt( dynamic_cast<DPrtPic*>( res.object ) );
    part.SetText( alias->GetPrt() ? alias->GetPrt()->GetName() : "" );
    }

  //part.Exit();
  //SelectDialog select( &WinProgram::winProgram->GetMainWindow()->GetProjectManager(), dptPrtPic, partName, "������" );
  //if( select.Execute( this ) ) part.Init();
  }

bool
WDAlias::WmSize( WPARAM, LPARAM ) {
  NPoint size( GetClientSize() );

  //������ ������
  NPoint hp(help.GetWindowPos()), hs(help.GetWindowSize());
  NPoint nhp( size.x - hs.x - 10, hp.y );
  help.SetWindowPos( nhp );

  //������ ���������
  NPoint ap(apply.GetWindowPos()), as(apply.GetWindowSize());
  NPoint nap( size.x - as.x - 10, ap.y );
  apply.SetWindowPos( nap );

  //������ ������� ������
  NPoint nlsp( nap.x - partSelect.GetWindowSize().x - 10, nap.y );
  partSelect.SetWindowPos( nlsp );

  //������ ������� ������
  NPoint nlpp( nhp.x - symbolSelect.GetWindowSize().x - 10, nhp.y );
  symbolSelect.SetWindowPos( nlpp );

  //������ �������������� �������
  NPoint nss( symbol.GetWindowSize() );
  symbol.SetWindowSize( NPoint( nlsp.x - symbol.GetWindowPos().x - 10, nss.y ) );

  //������ �������������� �������
  NPoint nps( part.GetWindowSize() );
  part.SetWindowSize( NPoint( nlpp.x - part.GetWindowPos().x - 10, nps.y ) );

  //���������
  NPoint ps( param.GetWindowPos() );
  param.SetWindowSize( NPoint( size.x - ps.x - ps.x, size.y - ps.y - ps.x ) );

  return false;
  }


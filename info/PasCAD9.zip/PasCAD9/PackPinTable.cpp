/*
DTableWnd
CPChar
PackPinTable::GetCell( DPoint cell ) {
  if( !symbol ) {
    tmp = "�� ������";
    return tmp;
    }
  if( cell.y ) return cell.x ? symbol->GetPinNumber( cell.y - 1, cell.x - 1 ) : symbol->GetPinName( cell.y - 1 );
  //���������
  if( cell.x ) {
    tmp = "������ ";
    tmp << cell.x;
    }
  else tmp = "�����";
  return tmp;
  }

void
PackPinTable::SetCell( DPoint cell, CPChar str ) {
  if( !symbol ) return;
  if( cell.y ) {
    if( cell.x ) symbol->SetPinNumber( str, cell.y - 1, cell.x - 1 );
    else symbol->SetPinName( str, cell.y - 1 );
    }
  }

int
PackPinTable::GetRowHigh( int row ) {
  return row ? 15 : 20;
  }

int
PackPinTable::GetColumnWide( int column ) {
  return column ? 60 : 70;
  }

int
PackPinTable::GetCellProp( DPoint cell ) {
  return cell.y ? scprEditEnable | scprChangeEnable;
  }

int
PackPinTable::GetCellDisplayFormat( DPoint cell ) {
  if( cell.y ) return cell.x ? DT_RIGHT : DT_CENTER;
  return DT_CENTER;
  };
*/


/*
������ "������������"
���� DBaseUserOperation.cpp
  ����������
    ���������� �������-������ ������ DBaseUserOperation
  �������
    13.05.02 ������
*/

#include "PasObj.h"

bool
DBaseUserOperator::Operation( DBasePic *pic ) {
  switch( pic->GetType() ) {
    case dptLinePic       : return FLinePic( dynamic_cast<DLinePic*>(pic) );
    case dptRectPic       : return FRectPic( dynamic_cast<DRectPic*>(pic) );
    case dptFillRectPic   : return FFillRectPic( dynamic_cast<DFillRectPic*>(pic) );
    case dptCirclePic     : return FCirclePic( dynamic_cast<DCirclePic*>(pic) );
    case dptArcPic        : return FArcPic( dynamic_cast<DArcPic*>(pic) );
    case dptTextPic       : return FTextPic( dynamic_cast<DTextPic*>(pic) );
    case dptSymbolPic     : return FSymbolPic( dynamic_cast<DSymbolPic*>(pic) );
    case dptSymPinPic     : return FSymPinPic( dynamic_cast<DSymPinPic*>(pic) );
    case dptSelectorPic   : return FSelectorPic( dynamic_cast<DSelectorPic*>(pic) );
    case dptSheetPic      : return FSheetPic( dynamic_cast<DSheetPic*>(pic) );
    case dptWirePic       : return FWirePic( dynamic_cast<DWirePic*>(pic) );
    case dptPrtPic        : return FPrtPic( dynamic_cast<DPrtPic*>(pic) );
    case dptPrtPinPic     : return FPrtPinPic( dynamic_cast<DPrtPinPic*>(pic) );
    case dptAliasPic      : return FAliasPic( dynamic_cast<DAliasPic*>(pic) );
    case dptSheetNetPic   : return FSheetNetPic( dynamic_cast<DSheetNetPic*>(pic) );
    case dptPlateNetPic   : return FPlateNetPic( dynamic_cast<DPlateNetPic*>(pic) );
    case dptSymImpPic     : return FSymImpPic( dynamic_cast<DSymImpPic*>(pic) );
    case dptPrtImpPic     : return FPrtImpPic( dynamic_cast<DPrtImpPic*>(pic) );
    case dptPlatePic      : return FPlatePic( dynamic_cast<DPlatePic*>(pic) );
    case dptWireNamePic   : return FWireNamePic( dynamic_cast<DWireNamePic*>(pic) );
    case dptLineSizePic   : return FLineSizePic( dynamic_cast<DLineSizePic*>(pic) );
    case dptCircleSizePic : return FCircleSizePic( dynamic_cast<DCircleSizePic*>(pic) );
    case dptViaPic        : return FViaPic( dynamic_cast<DViaPic*>(pic) );
    case dptTrasePic      : return FTrasePic( dynamic_cast<DTrasePic*>(pic) );
    case dptNetListPic    : return FNetListPic( dynamic_cast<DNetListPic*>(pic) );
    case dptTextDocPic    : return FTextDocPic( dynamic_cast<DTextDocPic*>(pic) );
    case dptAreaPic       : return FAreaPic( dynamic_cast<DAreaPic*>(pic) );
    case dptPolygonPic    : return FPolygonPic( dynamic_cast<DPolygonPic*>(pic) );
    case dptRegionPic     : return FRegionPic( dynamic_cast<DRegionPic*>(pic) );
    case dptIdentPic      : return FIdentPic( dynamic_cast<DIdentPic*>(pic) );
    default : throw( CadError("DBaseUserOperation::Operation: ��� ������� �� ��������������.") );
    }
  //return false;
  }


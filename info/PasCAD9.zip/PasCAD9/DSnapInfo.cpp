/*
������ "������������"
���� DSnapInfo.cpp
  ����������
    ���������� ������ DSnapInfo
  �������
    20.02.2002 ������
*/

#include "PasObjIterator.h"
#include <float.h>

DSnapInfo::DSnapInfo() :
  snapMask(0),
  destMask(0),
  distance(DBL_MAX),
  flag(0),
  netName(0) {}

bool
DSnapInfo::Test( DPoint p, int mask ) {
  if( (flag & dsifExExcl) && p == exclude )
    return false;
  if( (flag & dsifExSour) && p == sour )
    return false;
  double d = sour.GetDistance(p);
  if( d < distance ) {
    distance = d;
    dest     = p;
    destMask = mask;
    return true;
    }
  return false;
  }

bool
DSnapInfo::Layer( int idLayer ) {
  return DLayerManager::man.IsLayerAble( idLayer );
  }

class DIGetSnap : public DownIterator {
    DSnapInfo &info;
  public:
    DIGetSnap( DSnapInfo &i ) : info(i) {}

    virtual bool operation( DBasePic *base ) {
      DGraphObjectPic *pic = dynamic_cast<DGraphObjectPic*>(base);
      if( pic ) pic->SnapPoint( info );
      return true;
      }
  };


void
DSnapInfo::Calculate( DOwnerPic *object ) {
  if( object ) object->ForEach( DIGetSnap(*this) );
  }

void
DSnapInfo::Reset( bool /*resetDest*/ ) {
  distance = DBL_MAX;
  }


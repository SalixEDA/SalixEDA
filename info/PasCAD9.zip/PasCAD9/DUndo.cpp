/*
������ "������������"
���� DMemoryUndo.cpp
  ����������
    ������ ��������� ������
  �������
    17.03.2001 ������
*/

#include "PasObj.h"

enum {
  utBegin,
  utEnd,
  utDelete,
  utCreate,
  utObject };

DUndo::DUndo( DProjectPic *own, int undoBufLen ) :
  buffer( undoBufLen ),
  owner(own),
  head(0),
  tail(0),
  rptr(0),
  wpos(0),
  bAction(false),
  bObjWAct(false),
  bObjRAct(false),
  declObject( 100, 100, false ) {}

int
DUndo::LowWrite( const void *data, int len, int pos ) {
  CPChar sour = (CPChar)data;
  if( pos >= buffer.GetSize() ) pos = 0;
  while( len ) {
    buffer[pos++] = *sour++;
    if( pos >= buffer.GetSize() ) pos = 0;
    len--;
    if( pos == tail ) {
      //����������
      UObject obj;
      do {
        LowRead( &obj, sizeof(UObject), tail );
        if( obj.type == utDelete ) delete obj.object;
        tail = obj.next;
        }
      while( obj.type != utEnd && tail != head );
      if( tail == head ) {
        //����� ������� ����������, ��������
        bAction = false;
        bObjWAct = false;
        prev = tail;
        return head;
        }
      }
    }
  return pos;
  }

int
DUndo::LowRead( void *data, int len, int pos ) {
  PChar dest = (PChar)data;
  while( len ) {
    if( pos >= buffer.GetSize() ) pos = 0;
    *dest++ = buffer[pos++];
    len--;
    }
  if( pos >= buffer.GetSize() ) pos = 0;
  return pos;
  }

void
DUndo::Clear() {
  UObject obj;
  while( tail != head ) {
    LowRead( &obj, sizeof(UObject), tail );
    if( obj.type == utDelete ) delete obj.object;
    tail = obj.next;
    }
  }

void
DUndo::Read( void *buf, int size ) {
  if( !bObjRAct ) throw CadError( "DUndo::Read" );
  rptr = LowRead( buf, size, rptr );
  }

void
DUndo::Write( const void *buf, int size ) {
  if( bObjWAct ) head = LowWrite( buf, size, head );
  }

void
DUndo::BeginAction() {
  if( buffer.GetSize() ) {
    if( bObjWAct || bAction ) throw CadError( "DUndo::BeginAction" );
    bAction = true;
    UObject obj;
    obj.type = utBegin;
    obj.prev = actPrev = prev;
    obj.next = (head + sizeof(UObject)) % buffer.GetSize();
    prev = actStart = head;
    actStop = head = LowWrite( &obj, sizeof(UObject), head );
    }
  }

void
DUndo::EndAction( CPChar action ) {
  if( !bAction && tail == head ) return; //���� ��������
  if( !bAction ) throw CadError( "DUndo::EndAction" );
  bAction = false;
  if( actStop == head ) {
    //����� �� �������� ��������, ���������
    head = actStart;
    prev = actPrev;
    }
  else {
    UObject obj;
    obj.type = utEnd;
    obj.prev = prev;
    obj.param = 1 + (action ? strlen(action) : strlen(appAction));
    obj.next = (head + sizeof(UObject) + obj.param) % buffer.GetSize();
    prev = head;
    head = LowWrite( &obj, sizeof(UObject), head );
    head = LowWrite( action ? action : appAction.GetBuffer(), obj.param, head );
    }
  }

void
DUndo::AppendAction() {
  if( bObjWAct || bAction ) throw CadError( "DUndo::AppendAction" );
  if( Empty() ) {
    BeginAction();
    appAction = "";
    }
  else {
    head = prev;
    UObject obj;
    LowRead( &obj, sizeof(UObject), head );
    prev = obj.prev;
    bAction = true;
    }
  }

void
DUndo::OpenObject() {
  if( bAction ) {
    if( bObjWAct ) throw CadError( "DUndo::OpenObject" );
    bObjWAct = true;
    wobj.type = utObject;
    wobj.prev = prev;
    wobj.next = (head + sizeof(UObject)) % buffer.GetSize();
    wobj.object = 0;
    wpos = head;
    head = LowWrite( &wobj, sizeof(UObject), head );
    }
  }

void
DUndo::CloseObject( DBasePic *ptr ) {
  if( bAction ) {
    if( !bObjWAct ) throw CadError( "DUndo::CloseObject" );
    bObjWAct = false;
    wobj.next = head;
    wobj.object = ptr;
    LowWrite( &wobj, sizeof(UObject), wpos );
    prev = wpos;
    }
  }

void
DUndo::WritePtr( DBasePic *ptr ) {
  if( bObjWAct ) head = LowWrite( &ptr, sizeof(ptr), head );
  }

void
DUndo::DeleteObject( DBasePic *object ) {
  if( bAction && buffer.GetSize() ) {
    if( bObjWAct ) throw CadError( "DUndo::DeleteObject" );
    UObject obj;
    obj.type   = utDelete;
    obj.next   = (head + sizeof(UObject)) % buffer.GetSize();
    obj.prev   = prev;
    obj.object = object;
    prev = head;
    head = LowWrite( &obj, sizeof(UObject), head );
    }
  else {
    declObject.Destroy( object );
    delete object;
    }
  }

DBasePic*
DUndo::ReadPtr() {
  DBasePic *ptr;
  Read( &ptr, sizeof(ptr) );
  return TestBasePic( ptr ) || owner->IsObjectPresent(ptr) ? ptr : 0;
  }

void
DUndo::Restore() {
  declObject.ClearAll();
  while( !Empty() ) {
    UObject obj;
    rptr = LowRead( &obj, sizeof(UObject), prev );
    head = prev;
    prev = obj.prev;
    switch( obj.type ) {
      case utBegin : //���������� ����������
        return;
      case utEnd : //���������� �������� ����������
        break;
      case utDelete : //��������� ������
        if( !TestBasePic( obj.object ) )
          declObject.Add( obj.object );
        break;
      case utCreate : //��������� ������
        delete obj.object;
        break;
      case utObject : //��������� �������
        if( obj.object && (TestBasePic( obj.object ) || owner->IsObjectPresent(obj.object)) ) {
          bObjRAct = true;
          obj.object->Restore( this );
          bObjRAct = false;
          //declObject = obj.object;
          }
        break;
      }
    }
  }

bool
DUndo::Empty() {
  return head == tail;
  }



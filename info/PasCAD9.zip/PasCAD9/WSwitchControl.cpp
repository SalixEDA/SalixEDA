/*
������ "Windows"
���� WSwitchControl.cpp
  ����������
    ���������� WSwitchControl
  �������
    30.10.2001 ������
*/

#include "WinPasCAD.h"

void
WSwitchControl::SetButtons( int *buttons, int count, NDialog *owner ) {
  int x = 0;
  for( int i = 0; i < count; ++i ) {
    NToolButton *button = new NToolButton;
    button->state     = 0;
    button->style     = (i == 0 ? NToolButton::slGroup : 0) | NToolButton::slRadio | NToolButton::slMarker;
    button->leftTop.x = x;
    button->leftTop.y = 0;
    button->cmdRelease =
    button->cmdPress  = buttons[i];
    button->pCommand  = 0;
    button->bitMap.LoadBitmap( buttons[i] );
    x += NToolButton::width;
    AddButton( button, false );
    }
  RecalcSize();
  dialog = owner;
  }

int
WSwitchControl::GetPressed() {
  FOR_EACH( buttonTable )
    if( buttonTable[i]->state & NToolButton::stPressed ) return i;
  return -1;
  }

void
WSwitchControl::SetPressed( int k ) {
  FOR_EACH( buttonTable )
    if( k == i ) buttonTable[i]->state |= NToolButton::stPressed;
    else buttonTable[i]->state &= ~NToolButton::stPressed;
  InvalidateRect( 0 );
  }

bool
WSwitchControl::WmLButtonDown( WPARAM wParam, LPARAM lParam ) {
  NToolButtonWindow::WmLButtonDown( wParam, lParam );
  if( dialog ) dialog->WmNotifyCode( 0, WM_VSCROLL, 0 );
  return true;
  }


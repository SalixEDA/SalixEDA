/*
������ "������������"
���� WDMaster.cpp
����������
  ���������� WDMaster - ������ ������
             WListBrowser - ���� �������-������
�������
  30.10.2001 ������
*/

#include "WinPasCAD.h"
#define BM_DEFRESULT WM_USER5
/*
//==============================================================================
class WListBrowser : public NListBrowser {
    DMasterItemTable  table;
    DSelectResultEx  *result;
  public:
    WListBrowser( HWND hWnd );

    virtual void LowNavigate( CPChar path ); //���������� ������ ��������� � ������������ � �����
    virtual bool WmUser5( WPARAM, LPARAM );  //BM_DEFRESULT 0, DSelectResultEx*
  protected:
    virtual int     GetItemHigh() { return 24; }
    virtual void    GetBitMapItem( int item, NBitMap &bmp );
    virtual CPChar  GetItemText( int item );
    virtual int     GetItemNumber();
    virtual void    MousePress( int item );
    virtual void    MouseSelect( int item );
    virtual void    MouseUnselect( int item );
  };

WListBrowser::WListBrowser( HWND hWnd ) :
  NListBrowser( hWnd ),
  table( 20, 20, false ),
  result(0) {
    hArrow = NProgram::app->LoadCursor( ARROW_CUR );
    hHand  = NProgram::app->LoadCursor( POINT_CUR );
    ground = RGB(255,255,255);
    }

void
WListBrowser::LowNavigate( CPChar path ) {
  NString str(path);
  table.ClearAll();
  FOR_EACH( (WFrame::pFrame->toolTable) )
    (WFrame::pFrame->toolTable)[i]->AccumItems( str, table, 0 );
  CompleteNavigation();
  }

bool
WListBrowser::WmUser5( WPARAM, LPARAM lParam ) {  //BM_DEFRESULT 0, DSelectResultEx*
  result = (DSelectResultEx*)lParam;
  return true;
  }

void
WListBrowser::GetBitMapItem( int item, NBitMap &bmp ) {
  if( item >= 0 && item < table.GetNumber() ) table[item]->LoadBitmap( bmp );
  }

CPChar
WListBrowser::GetItemText( int item ) {
  if( item >= 0 && item < table.GetNumber() )
    return table[item]->name;
  return "������! WListBrowser::GetItemText";
  }

int
WListBrowser::GetItemNumber() {
  return table.GetNumber();
  }

void
WListBrowser::MousePress( int item ) {
  if( item >= 0 && item < table.GetNumber() && GetNavigator() )
    if( table[item]->Enter( GetNavigator()->path, result, this ) )
      GetParent().SendMessage( WM_COMMAND, IDOK, 0 );
  }

void
WListBrowser::MouseSelect( int item ) {
  if( item >= 0 && item < table.GetNumber() ) table[item]->Select( this );
  }

void
WListBrowser::MouseUnselect( int item ) {
  if( item >= 0 && item < table.GetNumber() ) table[item]->Unselect( this );
  }


//------------------------------------------------------------------------------
//--------------------- WDMaster -----------------------------------------------
WDMaster::WDMaster( DSelectResultEx *res, NNavigator *nav ) :
  NDialog( MASTER_DLG ),
  descr( IDC_SYMBOL_PARAM, this ),
  result(res),
  navigator(nav) {
    static NWindowClass<WListBrowser> browserClass("PasListBrowser",0,0,0,0);
    }

void
WDMaster::WmInit() {
  //���������� ���������
  SendDlgItemMessage( IDC_BROWSER, BM_SETNAVIGATOR, 0, (LPARAM)(navigator) );
  //���������� ����������
  SendDlgItemMessage( IDC_BROWSER, BM_DEFRESULT, 0, (LPARAM)(result) );
  }

bool
WDMaster::WmCommand( WPARAM wParam, LPARAM lParam ) {
  switch( LOWORD(wParam) ) {
    case IDC_BR_HOME : SendDlgItemMessage( IDC_BROWSER, BM_HOME ); break;
    case IDC_BR_BACK : SendDlgItemMessage( IDC_BROWSER, BM_BACK ); break;
    case ID_SETDESCR : descr.SetText( (CPChar)(lParam) ); break;
    default : return NDialog::WmCommand( wParam, lParam );
    }
  return true;
  }

*/


/*
������ "������������" ���������� ���������� ��� ������
���� nBase.h
  ����������
    �������� ������� � ����� ��� �������� � ������ ���������� �� ��� ������ ����������
  �������
    17.07.2000 ������
*/

#ifndef __NBASE_H
#define __NBASE_H

#ifndef __WINDOWS_H
  #include <windows.h>
#endif

#ifndef __SVECTOR_H
  #include <svector.h>
#endif

#define STM_IDC_TABLE        101
#define STM_IDC_SETSORTORDER 102
#define STM_IDC_SORTUP       103
#define STM_IDC_SORTDOWN     104
#define STM_IDC_SORTLIST     105
#define STM_SETTABLE WM_USER
#define STM_SETSORTORDER ((STM_SETTABLE) + 1)
#define STM_APPLY        ((STM_SETSORTORDER) + 1)

#define STM_TABLE_CLASS "SelectTable"
#define STM_SETSORT_DLG "STM_SORTORDERDLG"

template <class OVector, class Comparer>
int findIndex( OVector &vector, Comparer &cmp ) {
  for( int i = 0; i < vector.getNumber(); ++i )
    if( cmp == vector[i] ) return i;
  return -1;
  }

template <class OVector, class Oper>
void forEach( OVector &vector, Oper op ) {
  for( int i = 0; i < vector.getNumber(); ++i )
    op( vector[i] );
  }

//������� ���������
int ncfText( const char *c1, const char *c2 );

template <class Object> int
ncfRef( Object *c1, Object *c2 ) {
  return *c1 > *c2 ? 1 : ( *c1 < *c2 ? -1 : 0 );
  }

template <class Object> int
ncfPtr( Object * (*pc1), Object * (*pc2) ) {
  Object *c1 = *pc1, *c2 = *pc2;
  return *c1 > *c2 ? 1 : ( *c1 < *c2 ? -1 : 0 );
  }

//������� ������
void
npfText( char *dest, const char *sour );

void
npfInt( char *dest, const char *sour );

void
npfDouble( char *dest, const char *sour );

namespace NPFPhis {
  void npfPhis( char *dest, const char *sour );
  extern LPCSTR name;
  };


//============== ��������� ��������� �����
typedef int  (*NCompareFun)(const char *c1, const char *c2);
typedef void (*NPrintFun)(char *dest, const char *c1);

struct NFieldOperation {
  int          offset;
  NCompareFun  cmpFun;
  NPrintFun    prnFun;
  const char  *title;
  int          width;
  };

struct NFieldStruct {
  NFieldOperation *fields;
  int              num;
  };

template <class Record, class Source>
class NCursor {
    int     cur;
    Source *base;
  public:
    NCursor( Source *b, int c = 0 ) :
      base(b),
      cur(c) { }
    NCursor( NCursor &c ) :
      base(c.base),
      cur(c.cur) { }

    Record  *operator -> () { return (*base)[cur]; }
    NCursor &operator ++ () { cur++; return *this; }
    NCursor &operator -- () { cur--; return *this; }
    NCursor &operator += (int offset) { cur += offset; return *this; }
    NCursor &operator -= (int offset) { cur -= offset; return *this; }
    bool     operator == ( NCursor &c ) { return base == c.base && cur == c.cur; }
    bool     operator <= ( NCursor &c ) { return cur <= c.cur; }
    bool     operator >= ( NCursor &c ) { return cur >= c.cur; }
    bool     operator < ( NCursor &c ) { return cur < c.cur; }
    bool     operator > ( NCursor &c ) { return cur > c.cur; }
  };

class NFilterImp {
    VectorImp   *base;
    Vector<int>  map;
  public:
    NFilterImp( VectorImp *b );
    ~NFilterImp() { }

    char   *operator [] ( int i ) { return base->at( map[i] ); }
    int     getNumber() { return map.getNumber(); }
    int     mapping( int i ) { return map[i]; }
    int     unmap( int c );
    void    sort( NFieldOperation *cmpTable, int num );
    void    filter( NFieldOperation *cmpTable, int num, const char *test );
  };

class NSelectTable {
  protected:
    NFilterImp      *filter;
    int              start;
    int              cur;
    int              pageSize;
    int              high;

    void             draw( HDC hdc, RECT * );
    void             updateWindow();
    HWND             hWnd;
    HWND             hScroll;
  public:
    NSelectTable( HWND hW, LPCREATESTRUCT ) :
      hWnd( hW ),
      filter(0),
      start(0),
      hScroll(0),
      cur(0) { }

    bool init( void *param ) { return true; }
    void onCreate();
    void onExit();
    LRESULT wndProc( UINT msg, WPARAM wParam, LPARAM lParam );
    
    static void             fillClassInfo( HINSTANCE, WNDCLASS & );
    static NFieldOperation *cmpTable;
    static int              cmpNum;
  };


class NScaner {
  protected:
    NScaner *next; //��������� ���� ������
    int      len;  //����� ������ � �������������� ���������
  public:
    typedef char *NPChar;
    NScaner( int ln ) : next(0), len(ln) { }

    virtual void scan( char *sour, char *dest ) = 0;
    virtual void endScan( char *sour, char *dest ) { if( next ) next->scan( sour, dest + len ); }
    NScaner &operator + ( NScaner &s ) { next = &s; return s; }
    void blank( NPChar &ptr );
  };

class NScanerText : public NScaner {
  public:
    NScanerText( int ln ) : NScaner(ln) { }

    virtual void scan( char *sour, char *dest );
    NScaner &operator + ( NScaner &s ) { next = &s; return s; }
  };

class NScanerTextList : public NScaner {
  public:
    NScanerTextList( int ln ) : NScaner(ln) { }

    virtual void scan( char *sour, char *dest );
    virtual void endPartScan( char *sour, char *dest ) { if( next ) next->scan( sour, dest + len ); }
    NScaner &operator + ( NScaner &s ) { next = &s; return s; }
  };

class NScanerDouble : public NScaner {
  public:
    NScanerDouble() : NScaner( sizeof(double) ) { }

    virtual void scan( char *sour, char *dest );
    NScaner &operator + ( NScaner &s ) { next = &s; return s; }
  };

class NScanerPhis : public NScaner {
  protected:
    const char *name;
  public:
    NScanerPhis( const char *nm) : NScaner( sizeof(double) ), name(nm) { }

    virtual void scan( char *sour, char *dest );
    NScaner &operator + ( NScaner &s ) { next = &s; return s; }
  };

namespace NRowData {
  extern double ve6[], ve12[], ve24[], ve48[], ve96[], ve192[];
  };

BOOL CALLBACK
nselectDlgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
BOOL CALLBACK
nsortDlgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );

void
nselectHelpProc( HWND hWnd );
void
nsortHelpProc( HWND hWnd );

int
SelectDialog( HWND hParent, HINSTANCE hInst, int dlgId, NFilterImp *ft,
  NFieldOperation *ct, int cn, LPCSTR className );

#endif


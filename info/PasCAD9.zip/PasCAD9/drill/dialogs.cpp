/*
������ "������������"
���������� "������������ �� ���������"
���� dialogs.cpp
  ����������
    �������
  �������
    02.12.99 ������
*/
#include "drillh.h"
#include <sutil.h>
#include <stdio.h>
#include <math.h>

void
fillLayer( HWND hDlg, int id, int sel ) {
  //��������� ������
  for( int i = 0; i < mainLayers.getNumber(); ++i )
    SendDlgItemMessage( hDlg, id, CB_ADDSTRING, 0, (LPARAM)(LPCSTR)(mainLayers[i].name) );
  //��������� �������
  SendDlgItemMessage( hDlg, id, CB_SETCURSEL, sel, 0 );
  }

BOOL CALLBACK
methodDlg( HWND hDlg, UINT msg, WPARAM wParam, LPARAM ) {
  switch( msg ) {
    case WM_INITDIALOG :
      SendDlgItemMessage( hDlg, IDC_MH_BYPAD, BM_SETCHECK, BST_CHECKED, 0 );
      SendDlgItemMessage( hDlg, IDC_MH_BYPIN, BM_SETCHECK, BST_UNCHECKED, 0 );
      fillLayer( hDlg, IDC_HOLELAYER, holeLayer );
      fillLayer( hDlg, IDC_ORGLAYER, borderLayer );
      break;
    case WM_COMMAND :
      switch( LOWORD(wParam) ) {
        case IDC_NEXT :
          method = SendDlgItemMessage( hDlg, IDC_MH_BYPIN, BM_GETCHECK, 0, 0 ) == BST_CHECKED ? 0 : 1;
          holeLayer = SendDlgItemMessage( hDlg, IDC_HOLELAYER, CB_GETCURSEL, 0, 0 );
          borderLayer = SendDlgItemMessage( hDlg, IDC_ORGLAYER, CB_GETCURSEL, 0, 0 );
          EndDialog( hDlg, 1 );
          break;
        case IDCANCEL : EndDialog( hDlg, 10 ); break;
        case IDHELP : break;
        default : return FALSE;
        }
      break;
    default : return FALSE;
    }
  return TRUE;
  }



BOOL CALLBACK
diametrDlg( HWND hDlg, UINT msg, WPARAM wParam, LPARAM ) {
  switch( msg ) {
    case WM_INITDIALOG :
      break;
    case WM_COMMAND :
      switch( LOWORD(wParam) ) {
        case IDC_NEXT : EndDialog( hDlg, 2 ); break;
        case IDC_PREV : EndDialog( hDlg, 0 ); break;
        case IDCANCEL : EndDialog( hDlg, 10 ); break;
        case IDHELP : break;
        default : return FALSE;
        }
      break;
    default : return FALSE;
    }
  return TRUE;
  }

BOOL CALLBACK
typeDlg( HWND hDlg, UINT msg, WPARAM wParam, LPARAM ) {
  switch( msg ) {
    case WM_INITDIALOG :
      break;
    case WM_COMMAND :
      switch( LOWORD(wParam) ) {
        case IDC_NEXT : EndDialog( hDlg, 2 ); break;
        case IDC_PREV : EndDialog( hDlg, 0 ); break;
        case IDCANCEL : EndDialog( hDlg, 10 ); break;
        case IDHELP : break;
        default : return FALSE;
        }
      break;
    default : return FALSE;
    }
  return TRUE;
  }

BOOL
SetDlgItemFloat( HWND hDlg, int id, double val ) {
  char buf[80];
  sprintf( buf, "%g", val );
  return SetDlgItemText( hDlg, id, buf );
  }

double
GetDlgItemFloat( HWND hDlg, int id ) {
  char buf[80];
  GetDlgItemText( hDlg, id, buf, 80 );
  return atof( buf );
  }

BOOL CALLBACK
benchDlg( HWND hDlg, UINT msg, WPARAM wParam, LPARAM ) {
  switch( msg ) {
    case WM_INITDIALOG : {
      SendDlgItemMessage( hDlg, IDC_SORT, BM_SETCHECK, sortTool ? BST_CHECKED : BST_UNCHECKED, 0 );
      SendDlgItemMessage( hDlg, IDC_CUT, BM_SETCHECK, cutFile ? BST_CHECKED : BST_UNCHECKED, 0 );
      EnableWindow( GetDlgItem(hDlg, IDC_MAXSIZE), cutFile );
      for( int i = 0; i < maxTool; ++i )
        SendDlgItemMessage( hDlg, IDC_MLIST, LB_ADDSTRING, 0, (LPARAM)(benchTable[i]->getName()) );
      SendDlgItemMessage( hDlg, IDC_MLIST, LB_SETCURSEL, 0, 0 );
      setControlCheck( hDlg, IDC_DIR0, 4, 0 );
      SetDlgItemFloat( hDlg, IDC_X, ((double)origin.x) / 40.0 );
      SetDlgItemFloat( hDlg, IDC_Y, ((double)origin.y) / 40.0 );
      }
      break;
    case WM_COMMAND :
      switch( LOWORD(wParam) ) {
        case IDC_CUT :
          cutFile = SendDlgItemMessage( hDlg, IDC_CUT, BM_GETCHECK, 0, 0 ) == BST_CHECKED;
          EnableWindow( GetDlgItem(hDlg, IDC_MAXSIZE), cutFile );
          break;
        case IDC_NEXT :
          sortTool = SendDlgItemMessage( hDlg, IDC_SORT, BM_GETCHECK, 0, 0 ) == BST_CHECKED;
          bench = SendDlgItemMessage( hDlg, IDC_MLIST, LB_GETCURSEL, 0, 0 );
          dir = getControlCheck( hDlg, IDC_DIR0, 4 );
          orgBench.x = GetDlgItemFloat( hDlg, IDC_X ) * 40.0;
          orgBench.y = GetDlgItemFloat( hDlg, IDC_Y ) * 40.0;
          EndDialog( hDlg, 3 );
          break;
        case IDC_PREV : EndDialog( hDlg, 1 ); break;
        case IDCANCEL : EndDialog( hDlg, 10 ); break;
        case IDHELP : break;
        default : return FALSE;
        }
      break;
    default : return FALSE;
    }
  return TRUE;
  }



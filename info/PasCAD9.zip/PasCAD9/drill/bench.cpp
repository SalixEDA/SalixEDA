/*
������ "������������"
���������� "������������ �� ���������"
���� bench.cpp
  ����������
    ������������ ����������� ���������� ��� ������
  �������
    20.08.99 ������
*/
#include "drillh.h"
#include <stdio.h>
#include <fstream.h>

void
fillBenchTable() {
  benchTable[0] = new BenchSF4();
  benchTable[1] = new BenchVP910();
  }

void
Parity(unsigned char *buf, int sizeBuf) {
  unsigned char ch;
  int i;
  for (i=0; i<sizeBuf; i++) {
    ch=buf[i];
    ch=(unsigned char)(((ch<<1)^(ch<<2)^(ch<<3)^(ch<<4)^(ch<<5)^(ch<<6)^(ch<<7))& 0x80);
    buf[i]=buf[i] | ch;
    }
  }

Bench::Bench( LPCSTR nm ) :
  name(nm),
  parent(0),
  extension(".drl"),
  idFiles(0) {
    }

BOOL
Bench::writeString( OFile &os, LPCSTR str ) {
  return os.writeBytes( str, lstrlen(str) );
  }

BOOL
Bench::writeProlog( OFile& ) { return TRUE; }

BOOL
Bench::writeEpilog( OFile& ) { return TRUE; }

BOOL
Bench::translation( HWND h, int mfs, BOOL mfsEnable ) {
  //�������� �������� � ��������
  DPoint p;
  p = orgBench - origin;
  for( int i = 0; i < holeTable.getNumber(); ++i ) {
    holeTable[i].origin.rotate( origin, dir );
    holeTable[i].origin.move( p );
    }
  parent = h;
  //������� ����
  Path fileName;
  if( openFile( h, fileName, IDS_TITLE, idFiles, FALSE ) ) {
    HCURSOR hCursor = SetCursor( LoadCursor( NULL, (LPCSTR)IDC_WAIT ) );
    checkExtension( fileName, extension );
    OFile os(fileName);
    if( os.good() ) {
      //������������ ���������
      writeProlog( os );
      int i, fileCount = 0;
      for( i = 0; i < holeTable.getNumber(); )
        if( writeHole( os, holeTable[i].origin, holeTable[i].instrument ) ) {
          //����� ���������� ���������� ���������
          Hole hole = holeTable[i];
          int minRel = 2000000000;
          int n = -1;
          for( int k = i+1; k < holeTable.getNumber() && holeTable[k].instrument == hole.instrument; ++k )
            if( minRel > rel(hole.origin,holeTable[k].origin) ) {
              minRel = rel(hole.origin,holeTable[k].origin);
              n = k;
              }
          if( n > 0 && n != i+1 ) {
            //�������� ������
            hole = holeTable[i+1];
            holeTable[i+1] = holeTable[n];
            holeTable[n] = hole;
            }
          ++i;
          }
        else {
          if( writeEpilog( os ) ) {
            os.close();
            LPSTR ptr = strstr( fileName, extension );
            if( ptr ) {
              wsprintf( ptr, "%d%s", fileCount++, extension );
              if( os.open( fileName ) && writeProlog( os ) ) continue;
              }
            }
          break;
          }
      writeEpilog( os );
      os.close();
      if( i < holeTable.getNumber() ) MessageBox( parent, "������ ������ � ����", "������", MB_OK );
      }
    SetCursor( hCursor );
    }
  return TRUE;
  }

//==============================================================================
//------------------------------ ��-4 ------------------------------------------
BenchSF4::BenchSF4() :
  Bench( "��-4" ),
  prevTool(-1),
  prevPoint(),
  prevLXY() {
    extension = ".sf4";
    idFiles = IDS_SF4_FILES;
    }

BOOL
BenchSF4::writeProlog( OFile &os ) {
   const unsigned char Prolog[23] =
   {0xa5,0xa,0,0,0,								  //% - ������
    0x4e,0x30,0x30,0xb1,0x47,0x39,0xb1,0xa, //N001G91- G91 - �������. �������.
    0,0,0,
    0x4e,0x30,0x30,0xb2,0x4d,0x30,0x36};    //N002M06T -

  os.writeBytes(Prolog, 23 );
  return TRUE;
  }


BOOL
BenchSF4::writeEpilog( OFile &os ) {
  int sizeBuf=0;
  char buf[100];
/*  if ( !prevPoint.empty() ) {
    sprintf(buf,"N%03d",numbKadr++);
    sizeBuf=4;
    if (prevPoint.x!=0) {
      sprintf(buf+sizeBuf,"X%+06d",0-prevPoint.x);
      sizeBuf+=7;
      }
    if (prevPoint.y!=0) {
      sprintf(buf+sizeBuf,"Y%+06d",0-prevPoint.y);
      sizeBuf+=7;
      }
    buf[sizeBuf++]=0xa;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    }
*/
  if (stH!=0)
  {
    if (stH>1)
    {
      sprintf(buf+sizeBuf,"H%02d\n",stH);
      sizeBuf+=4;
    }
    buf[sizeBuf++]=0xa;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
  }
  sprintf( buf+sizeBuf,"N%03dG15\n",numbKadr++);
  sizeBuf+=8;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  sprintf( buf+sizeBuf,"N%03dM06\n",numbKadr++);
  sizeBuf+=8;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  sprintf( buf+sizeBuf,"N%03d",numbKadr);
  buf[sizeBuf+4]=0x8;
  buf[sizeBuf+5]=0xa;
  Parity((unsigned char*)(buf),sizeBuf+6);
  os.writeBytes(buf, sizeBuf+6 );
  return TRUE;
  }

ofstream tpc("1.txt");

BOOL
BenchSF4::writeHole( OFile &os, DPoint p, int tool ) {
  int sizeBuf=0;
  char buf[200];
  p *= 5;
  p /= 2;
  tpc<<p.x<<' '<<p.y<<'\n';

  if (prevTool<0) {
    sprintf(buf,"T%02d\n",tool);
    sizeBuf=4;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    sprintf( buf+sizeBuf,"N003Y%+06dF0760L22\n",p.y);
    sizeBuf+=20;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    sprintf(buf+sizeBuf,"N004G13X%+06dL11\n",p.x);
    sizeBuf+=18;
    numbKadr=5;
    setSverl=true;
    stH=0;
    }
  else
  {
    if( tool != prevTool ) {
      //����� �����������
      if (stH!=0)
      {
        if (stH>1)
        {
          sprintf(buf+sizeBuf,"H%02d\n",stH-1);
          sizeBuf+=4;
         }
        buf[sizeBuf++]=0xa;
        buf[sizeBuf++]=0;
        buf[sizeBuf++]=0;
        buf[sizeBuf++]=0;
      }
      sprintf( buf+sizeBuf, "N%03dG15\n",numbKadr++);
      sizeBuf+=8;
      buf[sizeBuf++]=0;
      buf[sizeBuf++]=0;
      buf[sizeBuf++]=0;
      sprintf(buf+sizeBuf,"N%03dM06T%02d\n",numbKadr++,tool);
      sizeBuf+=11;
      buf[sizeBuf++]=0;
      buf[sizeBuf++]=0;
      buf[sizeBuf++]=0;
      setSverl=false;
      stH=0;
      }
    //�������� ���������

    if (stH>0)
    {
       if ((prevLXY.x==p.x-prevPoint.x) && (prevLXY.y==p.y-prevPoint.y))
         ++stH;
         else
         {
           if (stH>1)
           {
             sprintf(buf+sizeBuf,"H%02d\n",stH);
             sizeBuf+=4;
           }
           else  buf[sizeBuf++]=0xa;
           buf[sizeBuf++]=0;
           buf[sizeBuf++]=0;
           buf[sizeBuf++]=0;
           stH=0;
         }
    }
    if (stH==0){
      if ((p.x!=prevPoint.x) || (p.y!=prevPoint.y))
      {
        sprintf( buf+sizeBuf, "N%03d",numbKadr++);
        sizeBuf+=4;
        if (!setSverl)
        {
         sprintf( buf+sizeBuf,"G13");
         sizeBuf+=3;
         setSverl=true;
        }
        if (p.x!=prevPoint.x)
        {
          sprintf( buf+sizeBuf, "X%+06d",p.x-prevPoint.x);
          sizeBuf+=7;
        }
        if (p.y!=prevPoint.y)
        {
          sprintf( buf+sizeBuf, "Y%+06d",p.y-prevPoint.y);
          sizeBuf+=7;
        }
        stH=1;
//      buf[sizeBuf++]=0xa;
      }
    }
  }
  if (sizeBuf>0) {
   Parity((unsigned char*)(buf),sizeBuf);
    os.writeBytes(buf, sizeBuf );
    }
  prevLXY.x=p.x-prevPoint.x;
  prevLXY.y=p.y-prevPoint.y;
  prevPoint=p;
  prevTool = tool;
  return TRUE;
  }


//==============================================================================
//------------------------------ ��-910 ----------------------------------------
BenchVP910::BenchVP910() :
  Bench( "��-910" ),
  prevTool(-1) {
    prevPoint.x=0;	//��������� �����
    prevPoint.y=0;
    extension = ".vp9";
    idFiles = IDS_VP910_FILES;
    }


BOOL
BenchVP910::writeProlog( OFile &os ) {
  os.writeBytes("\0xa5", 1 );
  return TRUE;
  }


BOOL
BenchVP910::writeHole( OFile &os, DPoint p, int tool ) {
  char buf[200];
  int sizeBuf=0;
  if ((prevTool != tool) && (prevTool != -1)) {
    if ((prevPoint.x!=0) || (prevPoint.y!=0)) {
      buf[sizeBuf++]=0xa;
      if (prevPoint.x!=0) {
        sprintf(buf+sizeBuf,"X%+06d",0-prevPoint.x);
        sizeBuf+=7;
        }
      if (prevPoint.y!=0) {
        sprintf(buf+sizeBuf,"Y%+06d",0-prevPoint.y);
        sizeBuf+=7;
        }
      prevPoint.x=0;
      prevPoint.y=0;
      }
    sprintf(buf+sizeBuf,"M39");
    sizeBuf+=3;
    }
  if (prevTool != -1) buf[sizeBuf++]=0xa;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  buf[sizeBuf++]=0;
  if (p.x!=prevPoint.x) {
    sprintf( buf+sizeBuf, "X%+06d",prevPoint.x-p.x);
    sizeBuf+=7;
    }
  if (p.y!=prevPoint.y) {
    sprintf( buf+sizeBuf, "Y%+06d",prevPoint.y-p.y);
    sizeBuf+=7;
    }
  if (sizeBuf>0) {
    Parity((unsigned char*)(buf),sizeBuf);
    os.writeBytes(buf, sizeBuf );
    }
  prevTool = tool;
  prevPoint.x=p.x;
  prevPoint.y=p.y;
  return TRUE;
  }


BOOL
BenchVP910::writeEpilog( OFile &os ) {
  int sizeBuf=0;
  char buf[100];
  if ((prevPoint.x!=0) || (prevPoint.y!=0)) {
    buf[sizeBuf++]=0xa;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    buf[sizeBuf++]=0;
    if (prevPoint.x!=0) {
      sprintf(buf+sizeBuf,"X%+06d",0-prevPoint.x);
      sizeBuf+=7;
      }
    if (prevPoint.y!=0) {
      sprintf(buf+sizeBuf,"Y%+06d",0-prevPoint.y);
      sizeBuf+=7;
      }
    prevPoint.x=0;
    prevPoint.y=0;
    }
  sprintf(buf+sizeBuf,"M39\0xa");
  sizeBuf+=4;
  Parity((unsigned char*)(buf),sizeBuf);
  os.writeBytes(buf, sizeBuf );
  return TRUE;
  }



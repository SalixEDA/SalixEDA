/*
������ "������������"
���������� "������������ �� ���������"
���� tables.cpp
  ����������
    ���������� ������� ������ ��� ������ ������������
  �������
    02.12.99 ������
*/
#include "drillh.h"


//==============================================================================
//----------------------------- DiametrTable -----------------------------------
class DiametrTable : public STable {
  public:
    DiametrTable( HWND hWnd, LPCREATESTRUCT lp ) :
      STable( hWnd, lp ) {
        size.x = 3;
        size.y = assocTable.getNumber() + 1;
        flag = stblRowHead;
        }
    virtual cpChar getCell( SCell cell );
    virtual void setCell( SCell cell, cpChar str );
    virtual int  getRowHigh( int row );
    virtual int  getColumnWide( int column );
    virtual SCellProp *getCellProp( SCell cell );
  };


cpChar
DiametrTable::getCell( SCell cell ) {
  static char buf[20];
  if( cell.y == 0 ) {
    //���������
    switch( cell.x ) {
      case 0 : return "�������";
      case 1 : return "����������";
      case 2 : return "���-��";
      }
    }
  else {
    int i;
    switch( cell.x ) {
      case 0 : i = assocTable[cell.y-1].diametr; break;
      case 1 : i = assocTable[cell.y-1].number; break;
      case 2 : i = assocTable[cell.y-1].count; break;
      }
    wsprintf( buf, "%d", i );
    }
  return buf;
  }

void
DiametrTable::setCell( SCell cell, cpChar str ) {
  if( cell.y && cell.x == 1 ) assocTable[cell.y-1].number = atoi( str );
  }


int
DiametrTable::getRowHigh( int row ) {
  return row ? 22 : 26;
  }

int
DiametrTable::getColumnWide( int column ) {
  static int width[3] = { 100, 130, 80 };
  return width[column];
  }

SCellProp*
DiametrTable::getCellProp( SCell cell ) {
  static SCellProp prop[2] = {
    { 0, 0, 1 },
    { 0, scprEditEnable|scprChangeEnable, 1 } };
  if( cell.y && cell.x == 1 ) return &(prop[1]);
  return &(prop[0]);
  }

typedef RegisterWndClass<DiametrTable> RegisterDiametrTable;

//==============================================================================
//----------------------------- TypeTable --------------------------------------
class TypeTable : public STable {
  public:
    TypeTable( HWND hWnd, LPCREATESTRUCT lp ) :
      STable( hWnd, lp ) {
        size.x = 4;
        size.y = assocTable.getNumber() + 1;
        flag = stblRowHead;
        }
    virtual cpChar getCell( SCell cell );
    virtual void setCell( SCell cell, cpChar str );
    virtual int  getRowHigh( int row );
    virtual int  getColumnWide( int column );
    virtual SCellProp *getCellProp( SCell cell );
  };


cpChar
TypeTable::getCell( SCell cell ) {
  static char buf[20];
  if( cell.y == 0 ) {
    //���������
    switch( cell.x ) {
      case 0 : return "���";
      case 1 : return "�������";
      case 2 : return "����������";
      case 3 : return "���-��";
      }
    }
  else {
    int i;
    switch( cell.x ) {
      case 0 : i = assocTable[cell.y-1].type; break;
      case 1 : i = assocTable[cell.y-1].diametr; break;
      case 2 : i = assocTable[cell.y-1].number; break;
      case 3 : i = assocTable[cell.y-1].count; break;
      }
    wsprintf( buf, "%d", i );
    }
  return buf;
  }

void
TypeTable::setCell( SCell cell, cpChar str ) {
  if( cell.y && cell.x == 2 ) assocTable[cell.y-1].number = atoi( str );
  }


int
TypeTable::getRowHigh( int row ) {
  return row ? 22 : 26;
  }

int
TypeTable::getColumnWide( int column ) {
  static int width[4] = { 50, 130, 130, 80 };
  return width[column];
  }

SCellProp*
TypeTable::getCellProp( SCell cell ) {
  static SCellProp prop[2] = {
    { 0, 0, 1 },
    { 0, scprEditEnable|scprChangeEnable, 1 } };
  if( cell.y && cell.x == 2 ) return &(prop[1]);
  return &(prop[0]);
  }

typedef RegisterWndClass<TypeTable> RegisterTypeTable;

//==============================================================================
//----------------------------- registerTables ---------------------------------
BOOL
registerTables() {
  return RegisterDiametrTable().execute(hInst,"DiametrTableClass") &&
         RegisterTypeTable().execute(hInst,"TypeTableClass");
  }


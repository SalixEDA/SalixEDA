#include <NWindow.h>
#include "..\PasObj.h"
//#include "..\PasObjIterator.h"
#include "..\ExpPasCAD.h"
#include "OutSpecRH.rh"

extern CPChar szSpecDescr;

//==============================================================================
//--------------- ������ �������� ----------------------------------------------
class WDProcess : public NDialog {
    NListBoxControl list;
  public:
    WDProcess() :
      NDialog( IDD_PROCESS ),
      list( IDC_HISTORY, this ) {}

    void Message( CPChar str ) { list.AddString( str ); }
  };

struct DSpecExport : public DMasterText {
    DPlatePic  *plate;
    WDProcess  *process;
  public:
    DSpecExport() :
      DMasterText( "������� � Specctra", szSpecDescr, IDC_BUTTON, 0 ),
      plate(0),
      process(0) {}
    virtual bool Enter( CPChar path, DSelectResultEx *result, NWindow *own ); //������� ������

            bool CheckNumeration( NWindow *own );
            bool CheckConturPlate( NWindow *own );
            bool CheckConturTrase( NWindow *own );
            bool CheckNet( NWindow *own );
            void Export( NWindow *own );
  };



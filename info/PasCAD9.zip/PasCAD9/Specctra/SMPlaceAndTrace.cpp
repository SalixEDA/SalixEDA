/*
������ "������������"
���������� "������� � SPECCTRA"
���� SMPlaceAndTrace.cpp
  ����������
    ���������� ������� SpecMaster::PlaceAndTrace
  �������
    05.10.02 ������ ��� ������ 10
*/

#include "specctra/SpecctraH.h"

CPChar szPlRt = "application_mode placement\n"
                "unplace all\n"
                "unsel all comp\n"
                "plc_post_process on\n"
                "secondary_connection off\n"
                "initplace  (prefer_spacing 0)    (prefer_grid 0 (image_type smd))    (prefer_same_side_for_small off)    (prefer_side front_only (image_type smd))    (prefer_orient  0 90 180 270 (side front) (image_type smd))    (prefer_orient  0 (side back) (image_type smd))     (prefer_grid 0 (image_type pin))    (prefer_side front_only (image_type pin))    (prefer_orient  0 (side front) (image_type pin))    (prefer_orient  0 (side back) (image_type pin))\n"
                "plc_post_process on\n"
                "autodiscrete (type small) (prefer_spacing 0)    (under_smd on) (prefer_grid 0 (image_type smd))        (prefer_orient 0 90 180 270 (side front) (image_type smd))    (prefer_orient 0 90 180 270 (side back) (image_type smd))    (prefer_grid 0 (image_type pin))    (prefer_side front_only (image_type pin))    (prefer_orient 0 90 180 270 (side front) (image_type pin))       (prefer_orient 0 90 180 270 (side back) (image_type pin))\n"
                "application_mode routing\n"
                "grid wire 125 (direction x) (offset 0)\n"
                "grid wire 125 (direction y) (offset 0)\n"
                "grid via 125 (direction x) (offset 0)\n"
                "grid via 125 (direction y) (offset 0)\n"
                "bus diagonal\n"
                "route 25\n"
                "miter     (style diagonal )\n"
                "write session express.ses\n";
void
SpecMaster::PlaceAndTrace( NWindow *parent, DSelectResultEx *res ) {
  Express( parent, res, szPlRt );
  }


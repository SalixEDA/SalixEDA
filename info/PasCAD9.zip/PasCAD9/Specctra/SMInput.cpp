/*
������ "������������"
���������� "�������/������ � SPECCTRA"
���� SMInput.cpp
  ����������
    ���������� ������� SpecMaster::Input
  �������
    05.10.02 ������ ��� ������ 10
*/

#include "specctra/SpecctraH.h"
#include <fstream.h>

//==============================================================================
//------------------ ���������� �������� ������� -------------------------------
const
  SpecNameLen = 32,
  SpecStringLen = 256;

struct SpecCoord {
  int value;
  operator DCoord () { return (DCoord)value; }
  int Scan( istream &is );
  static int resolution;
  };

class SpecPoint {
    SpecCoord x,y;
  public:
    SpecPoint() { }
    int Scan( istream &is );
    operator DPoint () { return DPoint(x,y); }
    void operator = (SpecPoint &p) { x = p.x; y = p.y; }
  };

class SpecName {
    char name[SpecNameLen];
  public:
    SpecName();
    SpecName( LPCSTR str );
    int Scan( istream &is );
    operator == (LPCSTR str);
    operator LPCSTR () const { return name; }
  };

class SpecString {
    char string[SpecStringLen];
  public:
    SpecString();
    SpecString( LPCSTR str );
    int Scan( istream &is );
    int ScanWithSpace( istream &is );
    operator == (LPCSTR str);
    operator LPCSTR () const { return string; }
  };

class SpecScaner {
  protected:
    SpecName     name;
    SpecScaner **scanerTable;
    int          scanerNum;
    int          ScanInt( istream &is );
  public:
    SpecScaner( LPCSTR str );
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
            int Need( istream &is, char ch );
            int NeedClose(istream &is) { return Need( is, ')' ); }
            int NeedOpen(istream &is) { return Need( is, '(' ); }
  };

class SpecIgnore : public SpecScaner {
  public:
    SpecIgnore( LPCSTR str ) : SpecScaner( str ) { }
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecPath : public SpecScaner {
  public:
    SpecPath() : SpecScaner( "path" ) { }
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecVia : public SpecScaner {
    SpecIgnore contact;
    SpecIgnore   attr;
    SpecScaner  *table[2];
  public:
    SpecVia();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecConnect : public SpecScaner {
    SpecIgnore   terminal;
    SpecScaner  *table[1];
  public:
    SpecConnect();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecWire : public SpecScaner {
    SpecPath     path;
    SpecConnect  connect;
    SpecIgnore   net;
    SpecIgnore   attr;
    SpecScaner  *table[4];
  public:
    SpecWire();
  };

class SpecNet : public SpecScaner {
    SpecWire     wire;
    SpecVia      via;
    SpecIgnore   type;
    SpecIgnore   attr;
    SpecScaner  *table[4];
  public:
    SpecNet();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );

    DPlateNetPic *net;
  };

class SpecNetwork : public SpecScaner {
    SpecNet      net;
    SpecScaner  *table[1];
  public:
    SpecNetwork();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecShape : public SpecScaner {
    SpecIgnore   circ;
    SpecIgnore   rect;
    SpecIgnore   path;
    SpecScaner  *table[3];
  public:
    SpecShape();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecPadstack : public SpecScaner {
    SpecShape    shape;
    SpecScaner  *table[1];
  public:
    SpecPadstack();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecLibrary : public SpecScaner {
    SpecPadstack padstack;
    SpecScaner  *table[1];
  public:
    SpecLibrary();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecLayer : public SpecScaner {
    SpecIgnore   type;
    SpecScaner  *table[1];
  public:
    SpecLayer();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecStructure : public SpecScaner {
    SpecLayer    layer;
    SpecScaner  *table[1];
  public:
    SpecStructure();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecResolution : public SpecScaner {
  public:
    SpecResolution() : SpecScaner( "resolution" ) { }
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecRoutes : public SpecScaner {
    SpecResolution resolution;
    SpecIgnore     parser;
    SpecStructure  structure;
    SpecLibrary    library;
    SpecNetwork    network;
    SpecIgnore     testPoints;
    SpecScaner    *table[6];
  public:
    SpecRoutes();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecPlace : public SpecScaner {
  public:
    SpecPlace() : SpecScaner( "place" ) { }
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecComponent : public SpecScaner {
    SpecPlace      place;
    SpecScaner    *table[1];
  public:
    SpecComponent();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecPlacement : public SpecScaner {
    SpecComponent   component;
    SpecResolution  resolution;
    SpecScaner     *table[2];
  public:
    SpecPlacement();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecSelf : public SpecScaner {
    SpecIgnore   created_time;
    SpecScaner  *table[1];
  public:
    SpecSelf();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecAncestor : public SpecScaner {
    SpecIgnore   created_time;
    SpecScaner  *table[1];
  public:
    SpecAncestor();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecKeepout : public SpecScaner {
  public:
    SpecKeepout() : SpecScaner( "keepout" ) {}
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecStructure2 : public SpecScaner {
    SpecResolution resolution;
    SpecKeepout    keepout;
    SpecScaner     *table[2];
  public:
    SpecStructure2();
  };

class SpecHistory : public SpecScaner {
    SpecAncestor   ancestor;
    SpecSelf       self;
    SpecScaner    *table[2];
  public:
    SpecHistory();
//    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

class SpecSession : public SpecScaner {
    SpecIgnore      base_design;
    SpecHistory     history;
    SpecPlacement   placement;
    SpecRoutes      routes;
    SpecStructure2  structure;
    SpecScaner     *table[5];
  public:
    SpecSession();
    virtual int Scan( istream &is, SpecMaster *master, DBasePic *basePic );
  };

//==============================================================================
//------------------ ���������� �������� ������� -------------------------------
//==============================================================================
//--------------------------- �����  -------------------------------------------
int
blank( istream &is ) {
  int ch;
  while( 1 ) {
    ch = is.peek();
    if( ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' ) {
      is.ignore();
      continue;
      }
    if( is.peek() == '#' ) {
      //������� ������ �����������
      char str[256];
      is.getline( str, 256 );
      continue;
      }
    break;
    }
  return is.eof() ? 0 : 1;
  }

/*
int
addObject( PDBasePic pic ) {
  DMsg msg(dmtAddObject);
  msg.pic = pic;
  picture->operMsg( msg );
  if( msg.stopFlag ) return 1;
  delete pic;
  return 0;
  }


BOOL
userDPrtImpPic( DPrtImpPic *prt, int param ) {
  DPoint *p = (DPoint *)param;
  if( p ) *p = prt->info.origin + prt->info.org;
  return TRUE;
  }

DPoint
calcOldPlacement( PDBasePic pic ) {
  DPoint p;
  if( pic->getType() == dptCompPic )
    userDPrtImpPic( (DPrtImpPic*)pic, (int)(&p) );
  return p;
  }
*/
//==============================================================================
//--------------------------- SpecCoord ----------------------------------------
int
SpecCoord::Scan( istream &is ) {
  int res = blank( is );
  is>>value;
  value /= resolution;
  return res;
  }

int SpecCoord::resolution;

//==============================================================================
//--------------------------- SpecPoint ----------------------------------------
int
SpecPoint::Scan( istream &is ) {
  return x.Scan( is ) && y.Scan( is );
  }

//==============================================================================
//--------------------------- SpecScaner ---------------------------------------
SpecScaner::SpecScaner( LPCSTR str ) :
  name(str),
  scanerTable(0),
  scanerNum(0) {
    }

SpecScaner::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  int res = 1;
  //���� ���������� �������
  do {
    blank( is );
    if( is.peek() == '(' ) {
      is.ignore();
      //���������, ������� ���
      blank( is );
      SpecName buf;
      res &= buf.Scan( is );
      int i;
      //����� ����������� ����� � �������
      for( i = 0; i < scanerNum; ++i )
        if( scanerTable[i]->name == buf ) {
          res &= scanerTable[i]->Scan( is, master, basePic );
          break;
          }
      if( i == scanerNum ) res = 0;
      }
    else if( is.peek() == ')' ) {
      is.ignore();
      break;
      }
    else res = 0;
    }
  while( res );
  return res;
  }

int
SpecScaner::Need( istream &is, char ch ) {
  int res = blank( is );
  if( is.peek() != ch ) return 0;
  is.ignore();
  return res;
  }

int
SpecScaner::ScanInt( istream &is ) {
  int val;
  is >> val;
  return val;
  }

//==============================================================================
//----------------------------- SpecName ---------------------------------------
SpecName::SpecName() {
  name[0] = 0;
  }

SpecName::SpecName( LPCSTR str ) {
  if( lstrlen(str) < SpecNameLen ) lstrcpy( name, str );
  else {
    lstrcpyn( name, str, SpecNameLen-1 );
    name[SpecNameLen-1] = 0;
    }
  }

SpecName::Scan( istream &is ) {
  int i;
  blank( is );
  if( IsCharAlphaNumeric( (char)is.peek() ) ) {
    for( i = 0; i < SpecNameLen-1 &&
         (IsCharAlphaNumeric( is.peek() ) ||
          is.peek() == '\'' ||
          is.peek() == '_'); ++i )
      name[i] = (char)is.get();
    name[i] = 0;
    return 1;
    }
  return 0;
  }

SpecName::operator == ( LPCSTR str ) {
  return lstrcmp( name, str ) == 0;
  }

//==============================================================================
//----------------------------- SpecString -------------------------------------
SpecString::SpecString() {
  string[0] = 0;
  }

SpecString::SpecString( LPCSTR str ) {
  if( lstrlen(str) < SpecStringLen ) lstrcpy( string, str );
  else {
    lstrcpyn( string, str, SpecStringLen-1 );
    string[SpecStringLen-1] = 0;
    }
  }

SpecString::Scan( istream &is ) {
  int i;
  blank( is );
  for( i = 0; i < SpecStringLen-1 && is.peek() > ' ' && !is.eof(); ++i ) {
//    if( is.peek() == '\\' ) is.ignore();
    string[i] = (char)is.get();
    }
  string[i] = 0;
  return 1;
  }

int
SpecString::ScanWithSpace( istream &is ) {
  int i;
  blank( is );
  for( i = 0; i < SpecStringLen-1 && is.peek() >= ' ' && !is.eof(); ++i ) {
    string[i] = (char)is.get();
    }
  string[i] = 0;
  return 1;
  }

SpecString::operator == ( LPCSTR str ) {
  return lstrcmp( string, str ) == 0;
  }


//==============================================================================
//----------------------------- SpecIgnore -------------------------------------
int
SpecIgnore::Scan( istream &is, SpecMaster*, DBasePic* ) {
  //���������� ��� �� �����
  while( is.peek() != ')' && !is.eof() ) is.ignore();
  if( !is.eof() ) {
    is.ignore();
    return is.eof() ? 0 : 1;
    }
  return 0;
  }

//==============================================================================
//------------------------- SpecPath -------------------------------------------
int
SpecPath::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  DBasePtr<DPlateNetPic> net( basePic, "SpecPath::Scan" );
  //���� ������������
  SpecName name;
  int res = name.Scan( is );
  if( res ) {
    DRoadProp rp;
    rp.layer = master->ConvertLayerSpP( name );
    //������ �������
    SpecCoord wide;
    res = wide.Scan( is );
    if( res ) {
      rp.width = wide;
      //��������� �������
      SpecPoint p1,p2;
      res = p1.Scan( is );
      while( res ) {
        blank( is );
        if( is.peek() == ')' ) break;
        res = p2.Scan( is );
        //�������� �������
        net->Insert( new DTrasePic( p1, p2, rp ) );
        //addObject( new DWirePic( p1, p2, *pProp ) );
        p1 = p2;
        }
      }
    }
  return res & NeedClose( is );
  }

//==============================================================================
//------------------------- SpecVia --------------------------------------------
SpecVia::SpecVia() :
  SpecScaner( "via" ),
  contact( "contact" ),
  attr( "attr" ) {
    table[0] = &contact;
    table[1] = &attr;
    scanerTable = table;
    scanerNum = 2;
    }

int
SpecVia::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  DBasePtr<DPlateNetPic> net( basePic, "SpecVia::Scan" );
  //��� ��
  DViaProp vp;
  vp.type = ScanInt( is );
  SpecPoint p;
  int res = p.Scan( is );
  //��������� ���������� ��������� � ��������� � ������
  net->Insert( new DViaPic( p, vp.type ) );
  //addObject( new DViaPic( topLayer, botLayer, p, *pProp ) );
  return res & SpecScaner::Scan( is, master, basePic );
  }

//==============================================================================
//------------------------- SpecConnect ----------------------------------------
SpecConnect::SpecConnect() :
  SpecScaner( "connect" ),
  terminal( "terminal" ) {
    table[0] = &terminal;
    scanerTable = table;
    scanerNum = 1;
    }

//==============================================================================
//------------------------- SpecWire -------------------------------------------
SpecWire::SpecWire() :
  SpecScaner( "wire" ),
  path(),
  connect(),
  net( "net" ),
  attr( "attr" ) {
    table[0] = &path;
    table[1] = &connect;
    table[2] = &net;
    table[3] = &attr;
    scanerTable = table;
    scanerNum = 4;
    }

//==============================================================================
//------------------------- SpecNet --------------------------------------------
SpecNet::SpecNet() :
  SpecScaner( "Net" ),
  wire(),
  via(),
  type( "type" ),
  attr( "attr" ) {
    table[0] = &wire;
    table[1] = &via;
    table[2] = &type;
    table[3] = &attr;
    scanerTable = table;
    scanerNum = 4;
    }

int
SpecNet::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  DBasePtr<DPlatePic> plate( basePic, "SpecNet::Scan" );
  SpecString name;
  if( name.Scan(is) ) {
    //���������� ��� ����
    DPlateNetPic *net = plate->GetNet( name );
    if( !net ) {
      //���� � �������� ������ �� ����������!
      process->Message( "������ ��� ������� ����" );
      NString msg( "���� \"" );
      msg << (CPChar)name;
      msg << "\" �� ���������� � �������, �� ���������� � Specctra!!! �������� DSN �������������� �������.";
      process->ErrorBox( msg );
      net = plate->CreateNet( name );
      }
    return SpecScaner::Scan( is, master, net );
    }
  return 0;
  }

//==============================================================================
//------------------------- SpecNetwork ----------------------------------------
SpecNetwork::SpecNetwork() :
  SpecScaner( "network_out" ),
  net() {
    table[0] = &net;
    scanerTable = table;
    scanerNum = 1;
    }

//==============================================================================
//------------------------- SpecShape ------------------------------------------
SpecShape::SpecShape() :
  SpecScaner( "shape" ),
  circ( "circ" ),
  rect( "rect" ),
  path( "path" ) {
    table[0] = &circ;
    table[1] = &rect;
    table[2] = &path;
    scanerTable = table;
    scanerNum = 3;
    }

//==============================================================================
//------------------------- SpecPadstack ---------------------------------------
SpecPadstack::SpecPadstack() :
  SpecScaner( "padstack" ),
  shape() {
    table[0] = &shape;
    scanerTable = table;
    scanerNum = 1;
    }

int
SpecPadstack::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  SpecName name;
  if( name.Scan(is) ) return SpecScaner::Scan( is, master, basePic );
  return 0;
  }

//==============================================================================
//------------------------- SpecLibrary ----------------------------------------
SpecLibrary::SpecLibrary() :
  SpecScaner( "library_out" ),
  padstack() {
    table[0] = &padstack;
    scanerTable = table;
    scanerNum = 1;
    }

//==============================================================================
//------------------------- SpecLayer ------------------------------------------
SpecLayer::SpecLayer() :
  SpecScaner( "layer" ),
  type( "type" ) {
    table[0] = &type;
    scanerTable = table;
    scanerNum = 1;
    }

int
SpecLayer::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  SpecName name;
  if( name.Scan(is) ) return SpecScaner::Scan( is, master, basePic );
  return 0;
  }

//==============================================================================
//------------------------- SpecStructure --------------------------------------
SpecStructure::SpecStructure() :
  SpecScaner( "structure_out" ),
  layer() {
    table[0] = &layer;
    scanerTable = table;
    scanerNum = 1;
    }

//==============================================================================
//------------------------- SpecResolution -------------------------------------
int
SpecResolution::Scan( istream &is, SpecMaster*, DBasePic* ) {
  SpecName name;
  int res = name.Scan(is);
  SpecCoord::resolution = ScanInt( is );
  return res & NeedClose( is );
  }

//==============================================================================
//------------------------- SpecRoutes -----------------------------------------
SpecRoutes::SpecRoutes() :
  SpecScaner( "routes" ),
  resolution(),
  parser( "parser" ),
  structure(),
  library(),
  network(),
  testPoints( "test_points" ) {
    table[0] = &resolution;
    table[1] = &parser;
    table[2] = &structure;
    table[3] = &library;
    table[4] = &network;
    table[5] = &testPoints;
    scanerTable = table;
    scanerNum = 6;
    }

//==============================================================================
//------------------------- SpecPlace ------------------------------------------
int
SpecPlace::Scan( istream &is, SpecMaster*, DBasePic *basePic ) {
  DBasePtr<DPlatePic> plate( basePic, "SpecPlace::Scan" );
  SpecName name;
  SpecPoint p;
  SpecName sideName;
  int res = name.Scan( is ) &&   //����������� �����������
            p.Scan( is ) &&      //����� ������������
            sideName.Scan( is ); //������� ����������
  int angle = ScanInt( is ) * 1000;//�������
  //��������������� ��������� ����������
  if( res ) {
    DPrtImpPic *prt = plate->FindCompById( name );
    if( prt ) {
      //�������� ���� �������� � ������� ������������
      DProp prop;
      prop.Clear();
      prt->GetPProp( prop );
      prop.prtImpProp.angle = angle;
      prop.prtImpProp.side  = sideName == "front" ? dsComp : dsSold;
      prt->SetPProp( prop );
      //�������� ��������������
      DPoint oldPos = prt->LookInfo().origin;
      prt->Move( DPoint(p) - oldPos );
      }
    }
  return res & NeedClose( is );
  }

//==============================================================================
//------------------------- SpecComponent --------------------------------------
SpecComponent::SpecComponent() :
  SpecScaner( "component" ),
  place() {
    table[0] = &place;
    scanerTable = table;
    scanerNum = 1;
    }

int
SpecComponent::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  SpecName name;
  int res = name.Scan( is ); //��� �������
  if( res ) res = SpecScaner::Scan( is, master, basePic );
  return res;
  }

//==============================================================================
//------------------------- SpecPlacement --------------------------------------
SpecPlacement::SpecPlacement() :
  SpecScaner( "placement" ),
  component(),
  resolution() {
    table[0] = &component;
    table[1] = &resolution;
    scanerTable = table;
    scanerNum = 2;
    }

//==============================================================================
//------------------------- SpecSelf -------------------------------------------
SpecSelf::SpecSelf() :
  SpecScaner( "self" ),
  created_time( "created_time" ) {
    table[0] = &created_time;
    scanerTable = table;
    scanerNum = 1;
    }

//==============================================================================
//------------------------- SpecAncestor ---------------------------------------
SpecAncestor::SpecAncestor() :
  SpecScaner( "ancestor" ),
  created_time( "created_time" ) {
    table[0] = &created_time;
    scanerTable = table;
    scanerNum = 1;
    }

int
SpecAncestor::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  SpecString str;
  int res = str.Scan( is );
  if( res ) res = SpecScaner::Scan( is, master, basePic );
  return res;
  }

//==============================================================================
//------------------------- SpecKeepout ----------------------------------------
int
SpecKeepout::Scan( istream &is, SpecMaster*, DBasePic* ) {
  while( is.peek() != ')' && !is.eof() ) is.ignore();
  if( !is.eof() ) {
    is.ignore();
    return is.eof() ? 0 : Need( is, ')' );
    }
  return 0;
  }

//==============================================================================
//------------------------- SpecStructure2 -------------------------------------
SpecStructure2::SpecStructure2() :
  SpecScaner( "structure" ),
  resolution(),
  keepout() {
    table[0] = &resolution;
    table[1] = &keepout;
    scanerTable = table;
    scanerNum = 2;
    }

//==============================================================================
//------------------------- SpecHistory ----------------------------------------
SpecHistory::SpecHistory() :
  SpecScaner( "history" ),
  ancestor(),
  self() {
    table[0] = &ancestor;
    table[1] = &self;
    scanerTable = table;
    scanerNum = 2;
    }

//==============================================================================
//------------------------- SpecSession ----------------------------------------
SpecSession::SpecSession() :
  SpecScaner( "session" ),
  base_design( "base_design" ),
  history(),
  placement(),
  routes(),
  structure() {
    table[0] = &base_design;
    table[1] = &history;
    table[2] = &placement;
    table[3] = &routes;
    table[4] = &structure;
    scanerTable = table;
    scanerNum = 5;
    }

int
SpecSession::Scan( istream &is, SpecMaster *master, DBasePic *basePic ) {
  SpecString str;
  //���������� ��������� - ����������
  blank( is );
  //������� ��������� ���������
  if( NeedOpen( is ) &&
      name.Scan( is ) &&
      name == "session" ) {
        //����������� ��� �����
        str.ScanWithSpace( is );
        if( SpecScaner::Scan( is, master, basePic ) ) return 1;
        }
  return 0;
  }

//==============================================================================
//------------------------- �������� �������� ���� ����� -----------------------
class DIWireDelete : public DownIterator {
    DSelectorPic sel;
  public:
    DIWireDelete() {}

    bool operation( DBasePic *pic ) {
      if( pic->GetType() == dptTrasePic || pic->GetType() == dptViaPic ) {
        DBasePtr<DGraphObjectPic> graph( pic, "DIWireDelete" );
        graph->Select( sel );
        }
      return true;
      }
    void Delete() { sel.DeleteAll(); }
  };


bool
SpecMaster::Input( CPChar name, DPlatePic *plate ) {
  ifstream is(name);
  if( !is.good() ) {
    NPath tmp( "�� ���� ������� ���� \"" );
    tmp << name << "\"";
    process->ErrorBox( tmp );
    return false;
    }

  //������ ��� ��������� ����
  DIWireDelete idel;
  plate->ForEach( idel );
  idel.Delete();

  //����������� ������
  SpecSession session;
  session.Scan( is, this, plate );
  is.close();
  return true;
  }




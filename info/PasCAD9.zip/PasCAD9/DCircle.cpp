/*
������ "������������"
���� dcircle.cpp
  ����������
    ���������� ������ DCirclePic
  �������
    20.07.97 ������
    02.04.2001 ������������� ��� ���������-�����������
*/

#include "pasobj.h"

DCirclePic::DCirclePic( DOwnerPic *own ) :
  DLinearPic(own) { }

DCirclePic::DCirclePic( DPoint center, DCoord radius, DLineProp &prp ) :
  DLinearPic( prp ) {
    info.center = center;
    info.radius = radius;
    }

void
DCirclePic::Draw( DContext &dc ) {
  dc.Circle( info.radius, info.center, prop );
  }

void
DCirclePic::Write( DStream &os ) {
  DLinearPic::Write( os );
  os.Write( &info, sizeof(DCircleInfo) );
  }

struct V10CircleInfo {
  DCoord    radius;   //���������� � 0.25��
  DPoint    center;
  DInt32    width;
  DInt32    type;
  DInt32    layer;
  };

void
DCirclePic::Read( DStream &is ) {
  if( is.GetVersion() == 10 ) {
    //��������� �������� ������� �������
    V10CircleInfo v10;
    is.Read( &v10, sizeof( V10CircleInfo ) );
    //���������� � ����� �������
    info.radius   = v10.radius * 25;
    info.center.x = v10.center.x * 25;
    info.center.y = v10.center.y * 25;
    prop.width = v10.width * 25;
    prop.type  = v10.type;
    prop.layer = v10.layer;
    }
  else {
    DLinearPic::Read( is );
    is.Read( &info, sizeof(DCircleInfo) );
    }
  }

PDBasePic
DCirclePic::Copy() {
  DCirclePic *circle = new DCirclePic( info.center, info.radius, prop );
  if( !circle ) throw( CadError("DCirclePic::Copy") );
  return circle;
  }

void
DCirclePic::SaveState() {
  DUndo *undo = GetUndo();
  if( undo ) {
    undo->OpenObject();
    (*undo) << prop;
    (*undo) << info;
    undo->CloseObject( this );
    }
  }

void
DCirclePic::Restore( DUndo *undo ) {
  (*undo) >> prop;
  (*undo) >> info;
  }

void
DCirclePic::Move( DPoint offset ) {
  info.center.Move( offset );
  }

void
DCirclePic::Rotate( DPoint center, DAngle angle ) {
  info.center.Rotate( center, angle );
  }

void
DCirclePic::Mirror( DPoint a, DPoint b ) {
  info.center.Mirror( a, b );
  }

void
DCirclePic::SelectByPoint( const DPoint p, DSelectorPic &selector ) {
  if( IsAble() ) {
    if( !GetSelect() && p.IsOnCircle(info.center,info.radius) ) {
      DoSelect( selector );
      }
    }
  }

void
DCirclePic::SelectByRect( const DRect &r, DSelectorPic &selector ) {
  if( IsAble() ) {
    if( !GetSelect() && r.IsAccross(
      DRect(info.center.x-info.radius, info.center.y-info.radius,
            info.center.x+info.radius, info.center.y+info.radius) ) ) {
        DoSelect( selector );
        }
    }
  }

int
DCirclePic::BehindCursor( DPoint p ) {
  if( IsAble() ) {
    if( p.IsOnCircle(info.center,info.radius) ) {
      return GetSelect() ? SEL_ELEM : UNSEL_ELEM;
      }
    }
  return 0;
  }

bool
DCirclePic::SnapPoint( DSnapInfo &snap ) {
  if( snap.Layer( prop.layer ) ) {
    if( snap & snapCenter ) {
      snap.Test( info.center, snapCenter );
      }
    if( snap & snapQuadrant ) {
      snap.Test( DPoint( info.center.x + info.radius, info.center.y), snapQuadrant );
      snap.Test( DPoint( info.center.x - info.radius, info.center.y), snapQuadrant );
      snap.Test( DPoint( info.center.x, info.center.y + info.radius), snapQuadrant );
      snap.Test( DPoint( info.center.x, info.center.y - info.radius), snapQuadrant );
      }
    return true;
    }
  return false;
  }

DRect
DCirclePic::GetOverRect() const {
  return DRect( info.center.x - info.radius, info.center.y - info.radius,
                info.center.x + info.radius, info.center.y + info.radius );
  }



/*
������ "������������"
���������� "������ ��� � �����"
���� WDPrice.cpp
  ����������
  �������
    17.09.2003 ������
*/
#include "Price/PriceH.h"

using namespace NCommon;

#define CL_FON     RGB(192,192,192)
#define CL_TITFON  RGB(128,192,192)

class TGridWindow : public NGridWindow {
    NUTable *table;
  public:
    TGridWindow( HWND );
    virtual CPChar GetCell( NPoint cell );
    virtual void   SetCell( NPoint cell, CPChar sour );
    virtual int    GetCellDisplayFormat( NPoint cell );
    virtual int    GetCellProp( NPoint cell );
    virtual int    GetRowHigh( int row );
    virtual int    GetColumnWide( int column );

    virtual bool WmUser0( WPARAM, LPARAM ); /* 0, NUTable *table */
    virtual bool WmUser1( WPARAM, LPARAM ); /* 0, 0 -> ������� ������ */
    virtual bool WmUser2( WPARAM, LPARAM ); /* 0, 0 �������� ���������� */
    virtual bool WmUser3( WPARAM, LPARAM ); /* 0, 0 �������� ����������� */
  private:
            void UpdateSize();
            void DisplayActualCell( NContext &dc, NPoint cell, int x, int y, int w, int h);
  };

TGridWindow::TGridWindow( HWND hWnd ) :
  NGridWindow( hWnd ),
  table(0) {
    flag = stblRowHead | stblNoSelHead;
    SetSize( 1, 1 );
    }

CPChar
TGridWindow::GetCell( NPoint cell ) {
  if( table ) {
    if( cell.y ) {
      cell.y--;
      return table->CGetCellText( cell );
      }
    else return table->GetField( cell.x ).title;
    }
  return "NoTable";
  }

void
TGridWindow::SetCell( NPoint cell, CPChar sour ) {
  if( table ) {
    if( cell.y && cell.x > 1 && cell.x < 4 ) {
      cell.y--;
      table->SetCellText( cell, sour );
      table->SetCellInt( NPoint( 4, cell.y), table->CGetCellInt( NPoint( 2, cell.y) ) * table->CGetCellInt( NPoint( 3, cell.y) ) );
      table->SetCellInt( NPoint( 5, cell.y), 1 );
      GetParent().SendMessage( WM_COMMAND, GetDlgCtrlID(GetHWND()), (LPARAM)(&cell) );
      }
    }
  }

int
TGridWindow::GetCellDisplayFormat( NPoint cell ) {
  if( cell.y ) return DT_LEFT | DT_WORDBREAK;
  return DT_CENTER | DT_WORDBREAK;
  }

int
TGridWindow::GetCellProp( NPoint cell ) {
  if( cell.y ) return scprEditEnable|scprChangeEnable;
  return 0;
  }

int
TGridWindow::GetRowHigh( int row ) {
  return row ? 25 : 30;
  }

int
TGridWindow::GetColumnWide( int column ) {
  if( table ) return table->GetField(column).width;
  return 50;
  }

void
TGridWindow::UpdateSize() {
  if( table ) SetSize( table->GetNumField() - 1, table->GetNumber() + 1 );
  else SetSize( 1,1 );
  }

//���������� ������� �������
bool
TGridWindow::WmUser0( WPARAM, LPARAM lParam ) {
  table = (NUFilterTable*)lParam;
  UpdateSize();
  Repaint();
  return true;
  }

//�������� ������� ������
bool
TGridWindow::WmUser1( WPARAM, LPARAM ) {
  *result = cur.y - 1;
  return true;
  }

//�������� ���������� ������� (����������)
bool
TGridWindow::WmUser2( WPARAM, LPARAM ) {
  UpdateSize();
  Move( NPoint( 0, size.y ), false );
  Repaint();
  return true;
  }

//�������� �����������
bool
TGridWindow::WmUser3( WPARAM, LPARAM ) {
  Repaint();
  return true;
  }


//==============================================================================
//------------------------ PriceControl ----------------------------------------
PriceControl::PriceControl( int id, NDialog *dlg, NUTable *tab ) :
  NControl( id, dlg, 0 ),
  table(tab) {
    static NWindowClass<TGridWindow> gridClass( "PriceTable", 0, 0, 0 );
    }



//==============================================================================
//------------------------ WDPriceSelect ---------------------------------------
int priceSelect;

class WDPriceSelect : public NDialog {
    NUGridControl table;
  public:
    WDPriceSelect( NUTable *pTab ) :
      NDialog( IDD_PRICESEL ),
      table( IDC_PTABLE, this, pTab ) {}

    virtual void CmOk();
  };

void
WDPriceSelect::CmOk() {
  priceSelect = table.GetCurRecord();
  NDialog::CmOk();
  }

//==============================================================================
//------------------------ WDPrice ---------------------------------------------
bool
WDPrice::WmCommand( WPARAM wParam, LPARAM lParam ) {
  switch( LOWORD(wParam) ) {
    case IDC_TSELECT : CmSelect(); break;
    default : return NDialog::WmCommand( wParam, lParam );
    }
  return true;
  }

void
WDPrice::CmSelect() {
  if( WDPriceSelect( sour ).Execute( this ) ) {
    //����� ��������, ��������
    int cur = table.GetCurRecord();
    dest->SetCellText( NPoint( 1, cur ), sour->CGetCellText( NPoint( nameId, priceSelect ) ) );
    dest->SetCellInt( NPoint( 2, cur ), sour->CGetCellInt( NPoint( costId, priceSelect ) ) );
    dest->SetCellInt( NPoint( 4, cur ), dest->CGetCellInt( NPoint( 2, cur) ) * dest->CGetCellInt( NPoint( 3, cur) ) );
    dest->SetCellInt( NPoint( 5, cur), 1 );
    table.Update();
    }
  }


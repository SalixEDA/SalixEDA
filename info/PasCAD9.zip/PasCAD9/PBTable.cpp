/*
������ "������������"
���� WDPBase.cpp
����������
  ���������� ������  PBTable
�������
  11.09.2002 ������
*/
#include "WinPasCAD.h"

PBTable::PBTable( int rs ) : recordSize(rs) {}

void
PBTable::Print( NPath &dest, PBInfo *info, int x, int y ) {
  Assert( !info );
  //�������� ������ ����
  CPChar data = CGet( y );
  if( data ) {
    //�������� ������ ����
    data += info->fields[x].offset;
    switch( info->fields[x].type ) {
      case PBFT_TEXT   : memcpy( dest.GetBuffer(), data, info->fields[x].param ); break;
      case PBFT_TYPE   :
      case PBFT_OBJECT : memcpy( dest.GetBuffer(), data, maxWName ); break;
      case PBFT_VALUE  : PrintValue( dest, info->fields[x], data ); break;
      default : CadError( "PBTable::Print: �������� ��� ����" );
      }
    }
  }

void
PBTable::PrintValue( NPath &dest, PBField &field, CPChar sour ) {
  static CPChar szRow[PB_ROWS] = { "E3", "E6", "E12", "E24", "E48", "E96", "E192" };
  PBFValue *val = (PBFValue*)sour;
  if( val->vmin == 0 ) {
    dest[0] = 0;
    }
  else {
    NPrintPhis( dest.GetBuffer(), field.phis, val->vmin );
    if( val->row ) {
      NPath tmp;
      NPrintPhis( tmp.GetBuffer(), field.phis, val->vmax );
      dest << ":" << (CPChar)tmp << ":";
      int mask = 1, mask2 = 0xfe;
      for( int i = 0; i < PB_ROWS; ++i ) {
        if( val->row & mask ) {
          dest << szRow[i];
          if( val->row & mask2 ) dest << ",";
          else break;
          }
        mask <<= 1;
        mask2 <<= 1;
        }
      }
    }
  }

void
PBTable::Scan( CPChar sour, PBInfo *info, int x, int y ) {
  Assert( !info );
  //�������� ������ ����
  PChar data = Get( y );
  if( data ) {
    //�������� ������ ����
    data += info->fields[x].offset;
    int len;
    switch( info->fields[x].type ) {
      case PBFT_TEXT   : len = NMin( info->fields[x].param - 1, (int)(strlen(sour)) );
                         memcpy( data, sour, len );
                         data[len] = 0;
                         break;
      case PBFT_TYPE   :
      case PBFT_OBJECT : len = NMin( (unsigned)(maxWName - 1), strlen(sour) );
                         memcpy( data, sour, len );
                         data[len] = 0;
                         break;
      case PBFT_VALUE  : ScanValue( sour, info->fields[x], data ); break;
      default : CadError( "PBTable::Scan: �������� ��� ����" );
      }
    }
  }

void
PBTable::ScanValue( CPChar sour, PBField &field, PChar data ) {
  static NSeparator sep(0);

  PBFValue *val = (PBFValue*)data;
  ZeroMemory( val, sizeof(PBFValue) );
  sep.Init( sour );
  if( sep.Separate( ':' ) ) {
    //����������� ��������
    val->vmin = NScanPhis( sep.GetLastItem(), field.phis );
    if( sep.Separate( ':' ) ) {
      //������������ ��������
      val->vmax = NScanPhis( sep.GetLastItem(), field.phis );
      //����������� ������ �����
      val->row = 0;
      while( sep.Separate( ',' ) ) {
        CPChar ptr = sep.GetLastItem();
        if( *ptr == 'e' || *ptr == 'E' || *ptr == '�' || *ptr == '�' ) {
          ptr++;
          if( *ptr == '6' ) val->row |= PB_E6;
          else if( *ptr == '3' ) val->row |= PB_E3;
          else switch( ptr[1] ) {
            case '2' : val->row |= PB_E12; break;
            case '4' : val->row |= PB_E24; break;
            case '8' : val->row |= PB_E48; break;
            case '6' : val->row |= PB_E96; break;
            case '9' : val->row |= PB_E192; break;
            }
          }
        }
      }
    }
  }

bool
PBTable::Match( CPChar sour, PBInfo *info, int y ) {
  for( int i = 0; i < info->fieldCount; ++i )
    if( !MatchField( sour, CGet(y), info->fields[i] ) ) return false;
  return true;
  }

bool
PBTable::ZeroMatch( CPChar sour, PBInfo *info, int y ) {
  for( int i = 0; i < info->fieldCount; ++i )
    if( !ZeroMatchField( sour, CGet(y), info->fields[i] ) ) return false;
  return true;
  }

bool
PBTable::MatchField( CPChar sour, CPChar dest, PBField &field ) {
  sour += field.offset;
  dest += field.offset;
  PBFValue *vs = (PBFValue*)sour;
  PBFValue *vd = (PBFValue*)dest;
  switch( field.type ) {
    case PBFT_TEXT    :
    case PBFT_TYPE    :
    case PBFT_OBJECT  : return strcmp( sour, dest ) == 0;
    case PBFT_VALUE   : if( vs->vmin == vd->vmin ) return true;
                        if( vd->vmin <= vs->vmin && vs->vmin <= vd->vmax ) return true;
                        return false;
    default : throw CadError( "PBTable::MatchField: �������� ��� ����" );
    }
  }

bool
PBTable::ZeroMatchField( CPChar sour, CPChar dest, PBField &field ) {
  sour += field.offset;
  dest += field.offset;
  PBFValue *vs = (PBFValue*)sour;
  PBFValue *vd = (PBFValue*)dest;
  switch( field.type ) {
    case PBFT_TEXT    :
    case PBFT_TYPE    :
    case PBFT_OBJECT  : return !(*sour) || strcmp( sour, dest ) == 0;
    case PBFT_VALUE   : if( vs->vmin == vd->vmin || vs->vmin == 0 ) return true;
                        if( vd->vmin <= vs->vmin && vs->vmin <= vd->vmax ) return true;
                        return false;
    default : throw CadError( "PBTable::MatchField: �������� ��� ����" );
    }
  }

